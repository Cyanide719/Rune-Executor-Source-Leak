﻿using System;
using System.Diagnostics;
using System.Net.Http;
using System.Security.Authentication;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

using RuneClientAuth;

using RuneExecutor.Classes;

namespace RuneExecutor {
    /// <summary>
    ///     Interaction logic for KeySystem.xaml
    /// </summary>
    public partial class KeySystem : Window {
        private const string                   ServiceName = "rune";
        private       PandaAuthorizationClient _pandaAuthorizationClient;

        public KeySystem() {
            InitializeComponent();
            _pandaAuthorizationClient = new PandaAuthorizationClient(new HttpClient(new HttpClientHandler() {
                SslProtocols = SslProtocols.Tls12,
                UseProxy     = false,
                UseCookies   = false
            }));
            Init();
        }

        public async void Init() {
            MainBorder.Opacity     = 0;
            MainBorderGrid.Opacity = 0;
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e) {
            Animations.DoubleAnimation(MainBorder, "Opacity", 1, 250);

            await Task.Delay(250);
            Animations.DoubleAnimation(MainBorderGrid, "Opacity", 1, 250);
        }

        private void DragBorders_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) DragMove();
        }

        private async void CloseBtn_Click(object sender, RoutedEventArgs e) {
            Animations.Fade(MainBorderGrid, MainBorderGrid.Opacity, 0, 250);

            await Task.Delay(350);

            // Doing this makes the height and width not "auto".
            MainBorder.Height = MainBorder.ActualHeight;
            MainBorder.Width  = MainBorder.ActualWidth;

            Animations.DoubleAnimation(MainBorder, "Height", Animations.Cubic, 0, 750);
            Animations.DoubleAnimation(MainBorder, "Width", Animations.Cubic, 0, 750);

            await Task.Delay(750);
            Animations.Fade(MainBorder, MainBorder.Opacity, 0, 250);

            await Task.Delay(250);
            Environment.Exit(0);
        }

        private void MinimizeBtn_Click(object sender, RoutedEventArgs e) {
            WindowState = WindowState.Minimized;
        }

        private async void SubmitKeyBtn_Click(object sender, RoutedEventArgs e) {
            // auth stuff here

            if (!await _pandaAuthorizationClient.IsKeyValid(InputKeyTxtBox.Text, utilities.GetHardwareId(), ServiceName)) {
#if DEBUG
                Debugger.Break();
#endif
                return;
            }

            // Return with failure.

            var execWindowInitializer = new ExecutorWindowInitializer();

            Animations.Fade(MainBorderGrid, MainBorderGrid.Opacity, 0, 250);

            await Task.Delay(350);

            // Doing this makes the height and width not "auto".
            MainBorder.Height = MainBorder.ActualHeight;
            MainBorder.Width  = MainBorder.ActualWidth;

            Animations.DoubleAnimation(MainBorder, "Height", Animations.Cubic, 0, 750);
            Animations.DoubleAnimation(MainBorder, "Width", Animations.Cubic, 0, 750);

            await Task.Delay(750);
            Animations.Fade(MainBorder, MainBorder.Opacity, 0, 250);

            await Task.Delay(250);
            await execWindowInitializer.LoadWindow();

            ExecutorWindowInitializer.executorWindow.Show();
            Close();
        }

        private void GetKeyBtn_Click(object sender, RoutedEventArgs e) {
            _pandaAuthorizationClient.TryOpenAuthPage(utilities.GetHardwareId(), ServiceName);
        }

        private void CopyKeyLinkBtn_Click(object sender, RoutedEventArgs e) {
            Clipboard.SetText($"https://pandadevelopment.net/getkey?service={ServiceName}&hwid={utilities.GetHardwareId()}");
        }
    }
}