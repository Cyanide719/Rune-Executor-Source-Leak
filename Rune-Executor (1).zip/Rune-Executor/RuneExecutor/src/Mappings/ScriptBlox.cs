﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using Newtonsoft.Json;

using RuneExecutor.Controls;

namespace RuneExecutor {
    public class ScriptBlox_SearchAPI {
        /// <summary>
        ///     General URL, unknown possibilities.
        /// </summary>
        public const string API_URL = "https://scriptblox.com/api/";

        /// <summary>
        ///     Search scripts with the API.
        /// </summary>
        public const string API_URL_SCRIPT_SEARCH = "https://scriptblox.com/api/script/search?";

        public static string AssembleURL(string query, int maxPostAmount, int page, bool free = true) {
            // https://scriptblox.com/api/script/search?q=Doors&mode=free&page=1
            var sb = new StringBuilder();
            var form = new FormUrlEncodedContent(new Dictionary<string, string> {
                ["q"]    = query,
                ["max"]  = maxPostAmount.ToString(),
                ["mode"] = free ? "free" : "paid",
                ["page"] = page.ToString(),
            });
            sb.Append(API_URL_SCRIPT_SEARCH).Append(form.ReadAsStringAsync().Result);
            return sb.ToString();
        }

        public static ScriptBloxAPI_Root? FromJson(string json) {
            try {
                var x = JsonConvert.DeserializeObject<ScriptBloxAPI_Root>(json);
                return x;
            }
            catch {
                return null;
            }
        }

        public class ScriptBloxAPI_Root {
            /// <summary>
            ///     Root Object.
            /// </summary>
            public Result result { get; set; }
        }

        public class Result {
            /// <summary>
            ///     The amount of pages found for this query.
            /// </summary>
            public int totalPages { get; set; }

            /// <summary>
            ///     The data on the scripts
            /// </summary>
            public Scripts[] scripts { get; set; }
        }

        public class Scripts {
            /// <summary>
            ///     The Internal Identifier of the Script in ScriptBlox.
            /// </summary>
            public string _id { get; set; }

            /// <summary>
            ///     The title of the script.
            /// </summary>
            public string title { get; set; }

            /// <summary>
            ///     The game the script runs in (If Universal it sort of describes the script)
            /// </summary>
            public Game game { get; set; }

            /// <summary>
            ///     The Script's URL (Custom Made)
            /// </summary>
            public string ScriptURL => $"https://scriptblox.com/script/{slug}";

            /// <summary>
            ///     Likely how the script is identified in ScriptBlox.
            /// </summary>
            public string slug { get; set; }

            /// <summary>
            ///     Is the script verified?
            /// </summary>
            public bool verified { get; set; }

            /// <summary>
            ///     View Count
            /// </summary>
            public int views { get; set; }

            /// <summary>
            ///     Does it have a key system?
            /// </summary>
            [JsonProperty("key")]
            public bool HasKeySystem { get; set; }

            /// <summary>
            ///     The link for the Key system.
            /// </summary>
            [JsonProperty("keyLink")]
            public string? KeySystemLink { get; set; }


            /// <summary>
            ///     Paid or Free.
            /// </summary>
            public string scriptType { get; set; }

            /// <summary>
            ///     The script is not exclusive to a game
            /// </summary>
            public bool isUniversal { get; set; }

            /// <summary>
            ///     If true the script is patched.
            /// </summary>
            public bool isPatched { get; set; }

            /// <summary>
            ///     Public or Private
            /// </summary>
            public string visibility { get; set; }

            /// <summary>
            ///     Unknown.
            /// </summary>
            public int rawCount { get; set; }

            /// <summary>
            ///     Unknown.
            /// </summary>
            public bool showRawCount { get; set; }

            /// <summary>
            ///     Script creation date.
            /// </summary>
            public string createdAt { get; set; }

            /// <summary>
            ///     Script update date.
            /// </summary>
            public string updatedAt { get; set; }

            public int __v { get; set; }

            /// <summary>
            ///     The script code.
            /// </summary>
            public string script { get; set; }

            /// <summary>
            ///     Matched? Usage couldn't be inferred lol.
            /// </summary>
            public string[] matched { get; set; }

            public CloudScriptItem IntoScriptItem() {
                return new CloudScriptItem(this.title, this.script, this.game.name, this.views.ToString(), this.game.ImageUrl, this.isPatched.ToString(),
                                           this.verified.ToString(), this.HasKeySystem ? this.KeySystemLink : null);
            }
        }

        public class Game {
            /// <summary>
            ///     Roblox place ID
            /// </summary>
            public long gameId { get; set; }

            /// <summary>
            ///     Roblox Place Name
            /// </summary>
            public string name { get; set; }

            /// <summary>
            ///     Script Image
            /// </summary>
            public string imageUrl { get; set; }

            public string? ImageUrl {
                get {
                    if (string.IsNullOrEmpty(imageUrl) ||
                        !Uri.IsWellFormedUriString(imageUrl, UriKind.Absolute)) {
                        if (imageUrl.Contains("/images/")) {
                            imageUrl = $"https://scriptblox.com{imageUrl}";
                        }
                        else {
                            return null;
                        }
                    }

                    return imageUrl;
                }
            }
        }
    }

    public class ScriptBlox_ScriptAPI {
        // TODO: DOCUMENT API.
        public static ScriptBlox_ScriptAPI_Root FromJson(string json) {
            try {
                return JsonConvert.DeserializeObject<ScriptBlox_ScriptAPI_Root>(json);
            }
            catch {
                return null;
            }
        }

        public class ScriptBlox_ScriptAPI_Root {
            public Script script { get; set; }
        }

        public class Script {
            public string       _id          { get; set; }
            public string       title        { get; set; }
            public TargetGame   game         { get; set; }
            public string       features     { get; set; }
            public ScriptTags[] tags         { get; set; }
            public string       script       { get; set; }
            public ScriptOwner  owner        { get; set; }
            public string       slug         { get; set; }
            public bool         verified     { get; set; }
            public bool         key          { get; set; }
            public int          views        { get; set; }
            public string       scriptType   { get; set; }
            public bool         isUniversal  { get; set; }
            public bool         isPatched    { get; set; }
            public string       visibility   { get; set; }
            public int          rawCount     { get; set; }
            public bool         showRawCount { get; set; }
            public string       createdAt    { get; set; }
            public string       updatedAt    { get; set; }
            public int          __v          { get; set; }
            public int          likeCount    { get; set; }
            public int          dislikeCount { get; set; }
            public string       id           { get; set; }
        }

        public class TargetGame {
            public long   gameId   { get; set; }
            public string name     { get; set; }
            public string imageUrl { get; set; }
        }

        public class ScriptTags {
            public string name { get; set; }
            public string _id  { get; set; }
            public string id   { get; set; }
        }

        public class ScriptOwner {
            public string _id            { get; set; }
            public string username       { get; set; }
            public bool   verified       { get; set; }
            public string role           { get; set; }
            public bool   isBanned       { get; set; }
            public string profilePicture { get; set; }
            public string createdAt      { get; set; }
            public string lastActive     { get; set; }
            public bool   online         { get; set; }
            public bool   idle           { get; set; }
            public bool   offline        { get; set; }
            public string id             { get; set; }
        }
    }

    public class ScriptBlox {
        private HttpClient _httpClient;

        public ScriptBlox(HttpClient client) {
            _httpClient = client;
        }

        public async Task<ScriptBlox_SearchAPI.ScriptBloxAPI_Root?> GetQueryAsync(string query, int page,
                                                                                  int    postCount,
                                                                                  bool   onlyFree = true) {
            var httpResponse =
                await _httpClient.GetAsync(ScriptBlox_SearchAPI.AssembleURL(query, postCount, page, onlyFree));
            return ScriptBlox_SearchAPI.FromJson(await httpResponse.Content.ReadAsStringAsync());
        }

        public async Task<ScriptBlox_ScriptAPI.ScriptBlox_ScriptAPI_Root?> GetScriptInformationAsync(string slug) {
            var httpResponse = await _httpClient.GetAsync($"https://scriptblox.com/api/script/{slug}");
            return ScriptBlox_ScriptAPI.FromJson(await httpResponse.Content.ReadAsStringAsync());
        }
    }

}