﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace RuneExecutor {
    public static class Animations {
        public static DispatcherTimer Timer;

        public static IEasingFunction Quad { get; set; } = new QuadraticEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Sine { get; set; } = new SineEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Back { get; set; } = new BackEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Bounce { get; set; } = new BounceEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Circle { get; set; } = new CircleEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Cubic { get; set; } = new CubicEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Elastic { get; set; } = new ElasticEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Exponential { get; set; } = new ExponentialEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Power { get; set; } = new PowerEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Quartic { get; set; } = new QuarticEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static IEasingFunction Quintic { get; set; } = new QuinticEase {
            EasingMode = EasingMode.EaseInOut
        };

        public static Task AnimateText(DependencyObject Object, string Property, string Text, int Milliseconds = 5) {
            var Prop = Object.GetType().GetProperty(Property);
            if (Prop == null || !(Prop.GetValue(Object) is string CurrentText)) return Task.CompletedTask;

            // var Letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890~`!@#$%^&*()_+{}|\\/<>;':\"";
            var Iteration = 0.0;

            if (Timer != null) {
                Timer.Stop();
                Timer = null;
            }

            Timer = new DispatcherTimer {
                Interval = TimeSpan.FromMilliseconds(Milliseconds)
            };

            Timer.Tick += (sender, args) => {
                // var NewText = new string(CurrentText.Select((c, i) => i < Iteration ? Text[i] : Letters[new Random().Next(0, Letters.Length - 1)]).ToArray());

                Prop.SetValue(
                    Object,
                    new string(CurrentText.Select((c, i) => i < Iteration
                                                      ? Text[i]
                                                      : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890~`!@#$%^&*()_+{}|\\/<>;':\""
                                                          [new Random().Next(0, 86)]).ToArray()));

                if (Iteration >= Text.Length) {
                    Timer.Stop();
                    Timer = null;
                }

                Iteration += 1.0 / 3.0;
            };

            Timer.Start();

            return Task.CompletedTask;
        }

        public static void ObjectMove(DependencyObject Object, Thickness Get, Thickness Set, IEasingFunction Easing, int MilliSeconds = 750,
                                      bool             AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new ThicknessAnimation {
                EasingFunction = Easing,
                From           = Get,
                To             = Set,
                AutoReverse    = AutoReverse,
                Duration       = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(FrameworkElement.MarginProperty));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void ObjectMove(DependencyObject Object, Thickness Set, IEasingFunction Easing, int MilliSeconds = 750,
                                      bool             AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new ThicknessAnimation {
                EasingFunction = Easing,
                To             = Set,
                AutoReverse    = AutoReverse,
                Duration       = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(FrameworkElement.MarginProperty));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void Fade(DependencyObject Object, double From = 0, double To = 1, int MilliSeconds = 500, bool AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new DoubleAnimation {
                From        = From,
                To          = To,
                AutoReverse = AutoReverse,
                Duration    = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath("Opacity", 1));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void DoubleAnimation(DependencyObject Object, string Property, double To = 1, int MilliSeconds = 500,
                                           bool             AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new DoubleAnimation {
                To          = To,
                AutoReverse = AutoReverse,
                Duration    = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(Property, 1));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void DoubleAnimation(DependencyObject Object, string Property, IEasingFunction Easing, double From = 0, double To = 1,
                                           int              MilliSeconds = 500, bool AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new DoubleAnimation {
                From           = From,
                To             = To,
                EasingFunction = Easing,
                AutoReverse    = AutoReverse,
                Duration       = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(Property, 1));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void DoubleAnimation(DependencyObject Object,             string Property, IEasingFunction Function, double To = 1,
                                           int              MilliSeconds = 500, bool   AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new DoubleAnimation {
                To             = To,
                EasingFunction = Function,
                AutoReverse    = AutoReverse,
                Duration       = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(Property, 1));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void ColorAnimation(DependencyObject Object, string Property, Color From, Color To, int MilliSeconds = 350,
                                          bool             AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new ColorAnimation {
                From        = From,
                To          = To,
                AutoReverse = AutoReverse,
                Duration    = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(Property));

            Board.Children.Add(Animation);
            Board.Begin();
        }

        public static void ColorAnimation(DependencyObject Object, string Property, Color To, int MilliSeconds = 350,
                                          bool             AutoReverse = false) {
            var Board = new Storyboard();
            var Animation = new ColorAnimation {
                To          = To,
                AutoReverse = AutoReverse,
                Duration    = new Duration(TimeSpan.FromMilliseconds(MilliSeconds))
            };

            Storyboard.SetTarget(Animation, Object);
            Storyboard.SetTargetProperty(Animation, new PropertyPath(Property));

            Board.Children.Add(Animation);
            Board.Begin();
        }
    }
}