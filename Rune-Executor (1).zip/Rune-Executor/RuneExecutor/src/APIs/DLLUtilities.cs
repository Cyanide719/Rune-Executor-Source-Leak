﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace RuneExecutor.APIs {
    public static class DLLUtilities {

        public enum ReturnTypes {
            InjectSuccess         = 0,
            InjectFailure         = 1,
            AlreadyInjected       = 2,
            InstallingDLL         = 3,
            DLLNotFound           = 4,
            NoRobloxUWP           = 5,
            NoRobloxWeb           = 6,
            UnsupportedUWPVersion = 7,
            UnsupportedWebVersion = 8,
            Exception             = 9,
            UnknownError          = 10
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool WaitNamedPipe(string name, int timeout);


        // public static string CurrentDLL = Properties.Settings.Default.DLL.ToLower();

        public static Task KillRoblox(bool uwp = true) {
            if (uwp)
                foreach (var process in Process.GetProcessesByName("Windows10Universal"))
                    process.Kill();

            return Task.CompletedTask;
        }

        public static bool NamedPipeExists(string pipe) {
            try {
                if (!WaitNamedPipe(Path.GetFullPath($"\\\\.\\pipe\\{pipe}"), 0))
                    switch (Marshal.GetLastWin32Error()) {
                        case 0:
                        case 2:
                            return false;
                    }

                return true;
            }
            catch (Exception) {
                return false;
            }
        }

        public static void Execute(string text) {
            if (string.IsNullOrEmpty(text) || text == string.Empty || string.IsNullOrWhiteSpace(text)) return;

            /*
            string dll = Properties.Settings.Default.DLL.ToLower();

            if ((dll.Contains("easy") || dll.Contains("ez")))
            {
                EasyXploits.Execute(text);
            }

            if (dll.Contains("oxy"))
            {
                OxygenU.Execute(text);
            }
            */
        }
    }
}