﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Win32;

namespace RuneExecutor.APIs {
    public abstract class RegistryHelper {
        public static bool get_key(string key) {
            if (Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null") != null)
                return Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null").ToString() == "true";
            return false;
        }

        public static string get_key_string(string key) {
            if (Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null") == null) return "null";
            return Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null").ToString();
        }

        public static int get_key_int(string key) {
            if (Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null") == null) return 0;
            return (int)Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null");
        }

        public static double get_key_double(string key) {
            if (Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null") == null) return 0.0;

            return (double)Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, "null");
        }

        public static void set_key(string key, string value) {
            Registry.SetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, value);
        }

        public static void set_key(string key, bool value) {
            Registry.SetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, value ? "true" : "false");
        }

        public static void set_key(string key, int value) {
            Registry.SetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, value);
        }

        public static void set_key(string key, double value) {
            Registry.SetValue("HKEY_CURRENT_USER\\Software\\OxygenU", key, value);
        }

        public static bool has_key(string dllHash) {
            return Registry.GetValue("HKEY_CURRENT_USER\\Software\\OxygenU", dllHash, "null") != null;
        }
    }

    public class OxygenU {
        [DllImport("bin\\oxygen_auth.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int start_auth();

        [DllImport("bin\\oxygen_auth.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool verify_auth(string key);

        [DllImport("bin\\oxygen_injector.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int inject_dll();

        [DllImport("bin\\oxygen_injector.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int run_script(string script);

        private static string get_file_sha384(string fileName) {
            using (var inputStream = File.OpenRead(fileName)) {
                return BitConverter.ToString(new SHA384Managed().ComputeHash(inputStream)).Replace("-", string.Empty).ToLower();
            }
        }

        public static void Execute(string text) {
            run_script(text);
        }

        public static Task<(bool, string, DLLUtilities.ReturnTypes)> Inject() {
            var processesByName = Process.GetProcessesByName("Windows10Universal");
            if (processesByName.Length == 0)
                return Task.FromResult<(bool, string, DLLUtilities.ReturnTypes)>(
                    (false, "Run the Microsoft Store (UWP) version of Roblox before injecting.", DLLUtilities.ReturnTypes.NoRobloxUWP));

            var result          = false;
            var reason          = "";
            var injectionResult = DLLUtilities.ReturnTypes.InjectFailure;

            new Thread((ThreadStart)async delegate {
                var stopWatch = new Stopwatch();
                stopWatch.Start();

                var mainModule = Process.GetProcessById(processesByName[0].Id).MainModule;
                if (mainModule != null) {
                    var fileName = mainModule.FileName;
                    var text     = get_file_sha384(fileName);
                    if (!RegistryHelper.has_key("dll_hash") || RegistryHelper.get_key_string("dll_hash") != text ||
                        !File.Exists("oxygen.dll"))
                        using (var webClient = new WebClient()) {
                            var text2 = await webClient.DownloadStringTaskAsync(
                                "https://oxygenu.xyz/windows/dll/get_dll_hash.php?hash=" + text);
                            if (!(text2 != "no")) {
                                reason =
                                    "You are running an unsupported version of the Microsoft Store (UWP) version of Roblox, Please wait a few hours for the Oxygen U DLL to update and try again.";
                                injectionResult = DLLUtilities.ReturnTypes.UnsupportedUWPVersion;
                            }

                            await webClient.DownloadFileTaskAsync(text2, "oxygen.dll");
                            RegistryHelper.set_key("dll_hash", text);
                        }
                }

                stopWatch.Stop();

                switch (inject_dll()) {
                    case 0:
                        try {
                            run_script(
                                (RegistryHelper.get_key("antiobs")
                                    ? "setfflag('Custom_AntiObsCapture', 'true')"
                                    : "setfflag('Custom_AntiObsCapture', 'false')") + "\n" + (RegistryHelper.get_key("discordblock")
                                    ? "setfflag('Custom_DiscordBlockAutoJoins', 'true')"
                                    : "setfflag('Custom_DiscordBlockAutoJoins', 'false')"));
                        }
                        catch { }

                        result          = true;
                        injectionResult = DLLUtilities.ReturnTypes.InjectSuccess;
                        break;
                    case 1:
                        injectionResult = DLLUtilities.ReturnTypes.DLLNotFound;
                        break;
                    case 2:
                        injectionResult = DLLUtilities.ReturnTypes.NoRobloxUWP;
                        break;
                    case 4:
                        injectionResult = DLLUtilities.ReturnTypes.UnknownError;
                        break;
                }
            }).Start();

            return Task.FromResult<(bool, string, DLLUtilities.ReturnTypes)>((result, reason, injectionResult));
        }
    }
}