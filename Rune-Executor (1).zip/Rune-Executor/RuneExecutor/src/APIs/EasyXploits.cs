﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RuneExecutor.APIs {
    public class EasyXploits {
        public static void Execute(string script) {
            if (DLLUtilities.NamedPipeExists("ocybedam"))
                using (var namedPipeClientStream = new NamedPipeClientStream(".", "ocybedam", PipeDirection.Out)) {
                    namedPipeClientStream.Connect();
                    using (var streamWriter = new StreamWriter(namedPipeClientStream, Encoding.Default, 999999)) {
                        streamWriter.Write(script);
                    }
                }
        }

        public static bool IsInjected() {
            return DLLUtilities.NamedPipeExists("ocybedam");
        }

        public static async Task<(bool, string, DLLUtilities.ReturnTypes)> Inject() {
            using (var webClient = new WebClient()) {
                try {
                    var info = (await webClient.DownloadStringTaskAsync("https://github.com/FilterDaniel/Update/raw/master/Module.txt"))
                       .Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    if (info[0] == "true") {
                        Process.Start(info[1]);
                        return (true, "", DLLUtilities.ReturnTypes.InstallingDLL);
                    }

                    if (DLLUtilities.NamedPipeExists("ocybedam")) return (false, "", DLLUtilities.ReturnTypes.AlreadyInjected);

                    await webClient.DownloadFileTaskAsync(await webClient.DownloadStringTaskAsync("https://easyexploits.com/eelink.txt"),
                                                          "./bin/dll/easyxploits.exe");

                    Process.Start("./bin/dll/easyxploits.exe");
                }
                catch (Exception e) {
                    return (false, e.Message, DLLUtilities.ReturnTypes.Exception);
                }
            }

            return (true, "", DLLUtilities.ReturnTypes.InjectSuccess);
        }
    }
}