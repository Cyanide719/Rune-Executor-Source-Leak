﻿using System;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using RuneExecutor.APIs;

namespace RuneExecutor.Controls {
    /// <summary>
    ///     Interaction logic for CloudScriptItem.xaml
    /// </summary>
    public partial class CloudScriptItem : UserControl, IComponentConnector {
        public string script = "";

        /*
        public async void SetImage(string img)
        {
            Img.Background = new ImageBrush(Utilities.BitmapToImageSource(await ScriptBloxAPI.Methods.Converter.ConvertWebPToBitmapInternal(img)))
            {
                Stretch = Stretch.UniformToFill
            };
        }
        */

        public CloudScriptItem(string  title,          string src, string game, string views, string img, string patched, string verified,
                               string? keyLink = null, bool   animate = true) {
            InitializeComponent();

            if (animate) {
                Opacity = 0;

                Animations.DoubleAnimation(this, "Opacity", Animations.Cubic, 1, 300);
            }

            script = src;
            /*
            if (title.Length > 15)
            {
                TitleLbl.Text = title.Substring(0, 15);
            }
            else
            {

            }
            */

            TitleLbl.ToolTip = title;
            TitleLbl.Text    = title;

            GameNameLbl.Text = game;

            ViewsLbl.Text = views;

            if (string.IsNullOrEmpty(views)) ViewsBorder.Visibility = Visibility.Collapsed;

            if (patched.ToLower().Contains("true")) {
                ImgBlur.Radius            = 30;
                ImgPlaceholderBlur.Radius = 30;
                PatchedLbl.Visibility     = Visibility.Visible;
            }

            ;

            if (verified.ToLower().Contains("true")) VerifiedIcon.Visibility = Visibility.Visible;

            if (!string.IsNullOrEmpty(keyLink) && !string.IsNullOrWhiteSpace(keyLink)) KeyBorder.Visibility = Visibility.Visible;

            if (img.EndsWith("jpg", StringComparison.OrdinalIgnoreCase) || img.EndsWith("jpeg", StringComparison.OrdinalIgnoreCase) ||
                img.EndsWith("png", StringComparison.OrdinalIgnoreCase)) {
                try {
                    Img.Background = new ImageBrush(new BitmapImage(new Uri(img))) {
                        Stretch = Stretch.UniformToFill
                    };
                }
                catch (RuntimeWrappedException) {
                    Img.Visibility            = Visibility.Collapsed;
                    ImgPlaceholder.Visibility = Visibility.Visible;
                }
                catch (NullReferenceException) {
                    Img.Visibility            = Visibility.Collapsed;
                    ImgPlaceholder.Visibility = Visibility.Visible;
                }
                catch (Exception) {
                    Img.Visibility            = Visibility.Collapsed;
                    ImgPlaceholder.Visibility = Visibility.Visible;
                }
            }
            else // if (img.EndsWith("webp", StringComparison.OrdinalIgnoreCase))
            {
                Img.Visibility            = Visibility.Collapsed;
                ImgPlaceholder.Visibility = Visibility.Visible;
            }

            /*
            else
            {
                Img.Visibility = Visibility.Collapsed;
                ImgPlaceholder.Visibility = Visibility.Visible;
            }
            */

            /*
            if (img.EndsWith(".webp", StringComparison.OrdinalIgnoreCase))
            {
                Img.Visibility = Visibility.Collapsed;
                ImgPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                try
                {
                    Img.Background = new ImageBrush(new BitmapImage(new Uri($"https://scriptblox.com{img}")))
                    {
                        Stretch = Stretch.UniformToFill
                    };
                }
                catch (NullReferenceException)
                {
                }
                catch (Exception)
                {
                }
            }
            */

            /*
            if (string.IsNullOrEmpty(img) || string.IsNullOrWhiteSpace(img) || img == string.Empty)
            {
                Img.Visibility = Visibility.Collapsed;
                ImgPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                try
                {
                    Img.Background = new ImageBrush(new BitmapImage(new Uri(img)))
                    {
                        Stretch = Stretch.UniformToFill
                    };
                }
                catch
                {
                    try
                    {
                        Img.Background = new ImageBrush(new BitmapImage(new Uri($"http://scriptblox.com{img}")))
                        {
                            Stretch = Stretch.UniformToFill
                        };
                    }
                    catch
                    {
                        Img.Visibility = Visibility.Collapsed;
                        ImgPlaceholder.Visibility = Visibility.Visible;
                    }
                }
            }
            */
        }

        private void ExecuteBtn_Click(object sender, RoutedEventArgs e) {
            DLLUtilities.Execute(script);
        }

        private void CopyBtn_Click(object sender, RoutedEventArgs e) {
            Clipboard.SetText(script);
        }

        private void MainBorder_MouseEnter(object sender, MouseEventArgs e) {
            Animations.ObjectMove(MainBorder, new Thickness(10, 5, 0, 5), Animations.Cubic, 300);
        }

        private void MainBorder_MouseLeave(object sender, MouseEventArgs e) {
            Animations.ObjectMove(MainBorder, new Thickness(10, 10, 0, 0), Animations.Cubic, 300);
        }
    }
}