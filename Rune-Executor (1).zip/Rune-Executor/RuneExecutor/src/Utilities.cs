﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;

using ICSharpCode.AvalonEdit.Rendering;

namespace RuneExecutor {
    public static class Utilities {
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetWindowDisplayAffinity(IntPtr handle, uint affinity);

        public static T GetTemplateItem<T>(this Control Element, string Name) {
            return Element.Template.FindName(Name, Element) is T _Name ? _Name : default;
        }

        /*
        public static void ExceptionMessageBox(Exception exception, bool show = true)
        {
            if (!show)
            {
                return;
            }

            if (MessageBox.Show($"An exception (error) occured, do you want to copy the error message?\r\n\r\nSource: {exception.Source}\r\n\r\nException Message: {exception.Message}\r\n\r\nInner Exception: {exception.InnerException}\r\n\r\nStack Trace: \r\n{(exception.StackTrace.Length > 1000 ? exception.StackTrace.Substring(0, 1000) + "... (Too Long)" : exception.StackTrace)}\r\n\r\nTarget Site (Method): {exception.TargetSite}", "Error Occured", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Clipboard.SetText($"Source: {exception.Source}\r\n\r\nException Message: {exception.Message}\r\n\r\nInner Exception: {exception.InnerException}\r\n\r\nStack Trace: \r\n{exception.StackTrace}\r\n\r\nTarget Site (Method): {exception.TargetSite}");
            }
        }
        */

        public static void ExceptionMessageBox(this Exception exception, string message = "", bool show = true) {
            if (!show) return;

            var errorText =
                $"Rune has caught an exception (error), do you want to copy the error message?\r\n\r\nSource: {exception.Source}\r\n\r\nException Message: {exception.Message}\r\n\r\nInner Exception: {exception.InnerException}\r\n\r\nStack Trace: \r\n{(exception.StackTrace.Length > 1000 ? exception.StackTrace.Substring(0, 1000) + "... (exceeds 1000 chars)" : exception.StackTrace)}\r\n\r\nTarget Site (Method): {exception.TargetSite}";

            if (!string.IsNullOrEmpty(message)) message += "\r\n\r\n";

            if (MessageBox.Show(message + errorText, "Error Occured", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                Clipboard.SetText(errorText);
        }
    }

    public class AvalonLineShortener : VisualLineElementGenerator {
        private readonly string Shorten = " ... (exceeds 300 chars)";

        public override int GetFirstInterestedOffset(int startOffset) {
            var Line = CurrentContext.VisualLine.LastDocumentLine;
            if (Line.Length > 300) {
                var offsetLength = Line.Offset + 300 - Shorten.Length;
                if (startOffset <= offsetLength) return offsetLength;
            }

            return -1;
        }

        public override VisualLineElement ConstructElement(int offset) {
            return new FormattedTextElement(Shorten, CurrentContext.VisualLine.LastDocumentLine.EndOffset - offset);
        }
    }
}