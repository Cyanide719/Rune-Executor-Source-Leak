﻿using System.Threading.Tasks;
using System.Windows;

namespace RuneExecutor.Classes {
    public class ExecutorWindowInitializer {
        // This class is to initialize the executor window.
        public static ExecutorWindow executorWindow;

        public ExecutorWindowInitializer() {
            executorWindow = new ExecutorWindow {
                ShowInTaskbar = false
            };
        }

        public Task LoadWindow() {
            // this is like a shortened version of a delegate function
            executorWindow.ExecutorWindowInitializedEvent += () => {
                executorWindow.Show();
                executorWindow.ShowInTaskbar = true;

                executorWindow.ResizeMode = ResizeMode.CanResizeWithGrip;
            };

            return Task.CompletedTask;
        }
    }
}