﻿namespace RuneExecutor {
    public static class Configuration {
        public static bool DeveloperMode = false;
    }
}