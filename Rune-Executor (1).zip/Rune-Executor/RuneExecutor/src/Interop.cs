﻿using System;
using System.Runtime.InteropServices;

namespace RuneExecutor {
    public class Interop {
        [DllImport("User32.dll", EntryPoint = "SetWindowDisplayAffinity", SetLastError = true)]
        public static extern bool SetWindowDisplayAffinity(IntPtr windowHandle, int displayAffinity);
    }
}