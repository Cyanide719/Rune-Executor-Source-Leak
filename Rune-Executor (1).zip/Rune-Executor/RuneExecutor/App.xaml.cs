﻿using System;
using System.Collections.Generic;
using System.Windows;

using RuneExecutor.Classes;

namespace RuneExecutor {
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {
        public Queue<Exception> exceptionQueue = new Queue<Exception>();

        public void ShowNextException() {
            if (exceptionQueue.Count > 0) {
                if (exceptionQueue.Count > 1) {
                    if (MessageBox.Show($"There are {exceptionQueue.Count} exceptions (errors) left, do you want to show them?",
                                        "Exceptions Left", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                        exceptionQueue.Dequeue().ExceptionMessageBox("Do you want to show the next exception?");
                }
                else {
                    exceptionQueue.Dequeue().ExceptionMessageBox();
                }

                if (exceptionQueue.Count > 0) Current.Dispatcher.Invoke(ShowNextException);
            }
        }

        protected override void OnStartup(StartupEventArgs e) {
            Current.DispatcherUnhandledException += (s, e_) => {
                /*
                if (e_.Exception.Source.ToLower().Contains("microsoft.web.webview2"))
                {
                    e_.Handled = true;

                    return;
                }
                */

                exceptionQueue.Enqueue(e_.Exception);

                if (exceptionQueue.Count == 1) ShowNextException();

                e_.Handled = true;
            };

            base.OnStartup(e);
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e) {
            ExecutorWindowInitializer.executorWindow?.AddTab(
                $"New Tab {ExecutorWindowInitializer.executorWindow.EditorTabControl.Items.Count + 1}.lua");
        }
    }
}