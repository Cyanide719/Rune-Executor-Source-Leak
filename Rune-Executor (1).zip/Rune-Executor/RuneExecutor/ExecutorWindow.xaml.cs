﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml;

using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;

using Material.Icons.WPF;

using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using RuneExecutor.APIs;
using RuneExecutor.Controls;
using RuneExecutor.Properties;

namespace RuneExecutor {
    /// <summary>
    ///     Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class ExecutorWindow : Window {
        public bool AlreadySetDocsInitScript = false;

        /*
        private async void DocumentationWebView_Loaded(object sender, RoutedEventArgs e)
        {
            if (!DocsAlreadyLoaded)
            {
                DocumentationWebView.Visibility = Visibility.Collapsed;

                using (HttpClient client = new HttpClient())
                {
                    DocumentationWebView.Source = new Uri(await client.GetStringAsync("https://github.com/VisageLabs/VisageAssets/raw/main/Docs/Link.bin"));
                }

                DocumentationWebView.Visibility = Visibility.Visible;

                DocsAlreadyLoaded = true;
            }
        }
        */

        public bool AlreadySetZoomFactorChangedEvent = false;

        public bool DocsAlreadyLoaded = false;

        public ExecutorWindow() {
            InitializeComponent();

            Init();
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e) {
            CloseWindow();
        }

        private void MaximizeBtn_Click(object sender, RoutedEventArgs e) {
            MaximizeRestore();
        }

        private void MinimizeBtn_Click(object sender, RoutedEventArgs e) {
            WindowState = WindowState.Minimized;
        }

        private void Editor_Loaded(object sender, RoutedEventArgs e) {
            switch (Settings.Default.EditorType.ToLower()) {
                case "monaco":
                    Editor.Source = new Uri($"file:///{Directory.GetCurrentDirectory()}/bin/monaco/editor.html");
                    break;

                case "ace":
                    Editor.Source = new Uri($"file:///{Directory.GetCurrentDirectory()}/bin/ace/editor.html");

                    // Editor.Source = new Uri("https://visagelabs.github.io/aceeditor/index.html");
                    break;
            }
        }

        private void Editor_CoreWebView2InitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs e) {
            if (e.IsSuccess) {
                // Editor.CoreWebView2.Settings.AreDevToolsEnabled = false;
                Editor.CoreWebView2.Settings.IsReputationCheckingRequired = true;
                Editor.CoreWebView2.Settings.IsGeneralAutofillEnabled     = false;
                Editor.CoreWebView2.Settings.IsStatusBarEnabled           = false;
                Editor.CoreWebView2.Profile.PreferredColorScheme          = CoreWebView2PreferredColorScheme.Dark;

                // Editor.EnsureCoreWebView2Async(controllerOptions: WebView2ControllerOptions);

                Editor.CoreWebView2.DOMContentLoaded += async (s, e_) => {
                    using (var client = new HttpClient()) {
                        Editor.ExecuteScriptAsync(
                            client.GetStringAsync("https://github.com/VisageLabs/VisageAssets/raw/main/Editor/MonacoFuncs.js").Result);
                    }

                    if (!SavedTabsLoaded && Settings.Default.SaveTabs) {
                        await Task.Delay(1000);
                        if (Directory.Exists("bin/tabs")) {
                            var hasFilesInTabsDir        = false;
                            var hasFilesInSelectedTabDir = false;

                            if (Directory.GetFiles("bin/tabs").Length > 0)
                                try {
                                    foreach (var file in new DirectoryInfo("bin/tabs").GetFiles())
                                        AddTab(file.Name, File.ReadAllText(file.FullName));

                                    hasFilesInTabsDir = true;
                                }
                                catch (Exception ex) {
                                    ex.ExceptionMessageBox();
                                }

                            if (Directory.Exists("bin/tabs/selected") && Directory.GetFiles("bin/tabs/selected").Length > 0)
                                try {
                                    var file = new DirectoryInfo("bin/tabs/selected").GetFiles()[0];

                                    AddTab(file.Name, File.ReadAllText(file.FullName));

                                    hasFilesInSelectedTabDir = true;
                                }
                                catch (Exception ex) {
                                    ex.ExceptionMessageBox();
                                }

                            if (!hasFilesInTabsDir && !hasFilesInSelectedTabDir) AddTab("Untitled1.lua");
                        }
                        else {
                            AddTab("Untitled1.lua");
                        }

                        SavedTabsLoaded = true;

                        EditorLoaded = true;
                    }

                    ;
                };
            }
        }

        private void EditorTabControl_Loaded(object sender, RoutedEventArgs e) {
            TabScrollBar = EditorTabControl.GetTemplateItem<ScrollViewer>("TabScrollViewer");

            /*
            if (!EditorTabControlEventsAttached)
            {
                EditorTabControl.GetTemplateItem<Button>("AddBtn").Loaded += (s, e_) =>
                {
                    if (!EditorTabControlEventsAttached)
                    {
                        EditorTabControl.GetTemplateItem<Button>("AddBtn").Click += (s_, e__) =>
                        {
                            AddTab($"Untitled{(EditorTabControl.Items.Count + 1)}.lua");
                        };
                    }

                    EditorTabControlEventsAttached = true;
                };

                EditorTabControlEventsAttached = true;
            }
            */
        }

        private void SideBorderTabButtonsChecked(object sender, RoutedEventArgs e) {
            if (!DontDoPagesSwitchEvent && e.Source.GetType() == typeof(ToggleButton)) {
                var btn = e.Source as ToggleButton;

                if (btn.Name.EndsWith("tabbtn", StringComparison.OrdinalIgnoreCase))
                    for (var i = 0; i < PagesTabControl.Items.Count; i++)
                        if ((PagesTabControl.Items[i] as TabItem).Header.ToString().ToLower() ==
                            btn.Name.Substring(0, btn.Name.Length - 6).ToLower()) {
                            PagesTabControl.SelectedIndex = i;

                            break;
                        }
                /*
                    foreach (TabItem tab in PagesTabControl.Items)
                    {
                        if (tab.Header.ToString().ToLower() == btn.Name.Substring(0, btn.Name.Length - 6).ToLower())
                        {
                            PagesTabControl.SelectedItem = tab;
                            break;
                        }
                    }
                    */
            }

            foreach (var obj in (SideBorder.Child as Grid).Children)
                if (obj.GetType() == typeof(ToggleButton) && !obj.Equals(e.Source) && !obj.Equals(InjectBtn))
                    (obj as ToggleButton).IsChecked = false;
        }

        private void SideBorderTabButtonsUnchecked(object sender, RoutedEventArgs e) {
            var toggleButtonsUnchecked = true;
            foreach (var obj in (SideBorder.Child as Grid).Children)
                if (obj.GetType() == typeof(ToggleButton) && (obj as ToggleButton).IsChecked == true && !obj.Equals(InjectBtn)) {
                    toggleButtonsUnchecked = false;
                    break;
                }

            if (toggleButtonsUnchecked) {
                UncheckPageTimer.Tick += (s, e_) => {
                    UncheckPageTimer.Stop();

                    (e.Source as ToggleButton).IsChecked = true;
                };

                UncheckPageTimer.Start();
            }
        }

        private void Window_Closing(object sender, CancelEventArgs e) {
            e.Cancel = true;

            CloseWindow();
        }

        private void ExecuteBtn_Click(object sender, RoutedEventArgs e) { }

        private void ClearBtn_Click(object sender, RoutedEventArgs e) {
            if (MessageBox.Show("Are you sure you want to clear the text of the current tab?", "Clear Confirmation",
                                MessageBoxButton.YesNo) == MessageBoxResult.Yes) {
                (EditorTabControl.SelectedContent as TextBox).Text = string.Empty;

                SetText(string.Empty, false);
            }
        }

        private async void SaveBtn_Click(object sender, RoutedEventArgs e) {
            var path = (EditorTabControl.SelectedItem as TabItem).Tag.ToString();

            if (string.IsNullOrEmpty(path) || string.IsNullOrWhiteSpace(path))
                SaveAs();
            else if (!File.Exists(path))
                SaveAs();
            else
                File.WriteAllText(path, await GetText());
        }

        private void SaveAsBtn_Click(object sender, RoutedEventArgs e) {
            SaveAs();
        }

        private void ScriptsBox_Loaded(object sender, RoutedEventArgs e) {
            ScriptsWatcher.Created += delegate { UpdateScripts(); };
            ScriptsWatcher.Changed += delegate { UpdateScripts(); };
            ScriptsWatcher.Deleted += delegate { UpdateScripts(); };
            ScriptsWatcher.Renamed += delegate { UpdateScripts(); };

            ScriptsWatcher.EnableRaisingEvents = true;
        }

        private void DragBorders_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (e.LeftButton == MouseButtonState.Pressed) DragMove();

            if (e.ClickCount >= 2) MaximizeRestore();
        }

        private void DragBorders_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) { }

        private void DragBorders_MouseMove(object sender, MouseEventArgs e) { }

        private async void MenuItem_Click(object sender, RoutedEventArgs e) {
            var txt = await GetText();

            switch (Settings.Default.EditorType.ToLower()) {
                case "monaco":
                    Settings.Default.EditorType = "Ace";

                    Editor.Source = new Uri($"file:///{Directory.GetCurrentDirectory()}/bin/ace/editor.html");

                    // Editor.Source = new Uri("https://visagedevelopment.github.io/aceeditor/index.html");

                    await Task.Delay(1000);
                    SetText(txt);
                    break;

                case "ace":
                    Settings.Default.EditorType = "Monaco";

                    Editor.Source = new Uri($"file:///{Directory.GetCurrentDirectory()}/bin/monaco/editor.html");

                    await Task.Delay(1000);
                    SetText(txt, false);
                    break;
            }

            Settings.Default.Save();

            // Editor.Reload();
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e) {
            ChangeMaximizeBtn(WindowState == WindowState.Maximized);
        }

        private void InjectCoverBorder_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (InjectBtn.IsChecked == true) {
                MessageBox.Show("Visage is already injected!", "Already Injected");
            }
            else {
                InjectBtn.IsChecked       = true;
                InjectCoverBorder.ToolTip = InjectCoverBorder.ToolTip.ToString().Replace("Inject | ", "Injected | ");
            }
        }

        private void OpenFileBtn_Click(object sender, RoutedEventArgs e) {
            var dialog = new OpenFileDialog {
                Title            = "Visage | Open File",
                Filter           = "Text Documents|*.txt|Lua Source Files|*.lua|Luau Source Files|*.luau|All Files & Contents|*.*",
                FilterIndex      = 4,
                RestoreDirectory = true,
                CheckFileExists  = true
            };

            if (dialog.ShowDialog() == true) AddTab(dialog.SafeFileName, File.ReadAllText(dialog.FileName));
        }

        private void ExecuteFileBtn_Click(object sender, RoutedEventArgs e) {
            var dialog = new OpenFileDialog {
                Title            = "Visage | Execute File",
                Filter           = "Text Documents|*.txt|Lua Source Files|*.lua|Luau Source Files|*.luau|All Files & Contents|*.*",
                FilterIndex      = 4,
                RestoreDirectory = true,
                CheckFileExists  = true
            };

            if (dialog.ShowDialog() == true) DLLUtilities.Execute(File.ReadAllText(dialog.FileName));
        }

        private async void HideScriptsBoxBtn_Click(object sender, RoutedEventArgs e) {
            if (ScriptsBoxCollapsed && !ScriptsBoxExpandingCollapsing) {
                ScriptsBoxExpandingCollapsing = true;

                ScriptsAndEditorColumnDefinition.MinWidth = 130;

                ScriptsAndEditorColumnDefinition.Width = Settings.Default.ScriptsBoxWidth;
                ScriptsEditorGridSplitter.Visibility   = Visibility.Visible;

                HideScriptsBoxBtn.IsChecked = false;

                ScriptsBoxExpandingCollapsing = false;
                ScriptsBoxCollapsed           = false;

                Settings.Default.IsScriptsBoxCollapsed = false;
            }
            else if (!ScriptsBoxCollapsed && !ScriptsBoxExpandingCollapsing) {
                ScriptsBoxExpandingCollapsing = true;

                Settings.Default.ScriptsBoxWidth = ScriptsAndEditorColumnDefinition.Width;

                ScriptsEditorGridSplitter.Visibility = Visibility.Collapsed;

                ScriptsAndEditorColumnDefinition.MinWidth = 20;

                ScriptsAndEditorColumnDefinition.Width = new GridLength(20);

                HideScriptsBoxBtn.IsChecked = true;

                ScriptsBoxExpandingCollapsing = false;
                ScriptsBoxCollapsed           = true;

                Settings.Default.IsScriptsBoxCollapsed = true;
            }
        }

        private void CloudScriptsSearchTimerTick(object sender, EventArgs e) {
            CloudScriptsSearchTimer.Stop();
            FetchSearchCloudScripts(true);
        }

        private void CloudScriptsPagesTxtBox_PreviewTextInput(object sender, TextCompositionEventArgs e) {
            if (!char.IsDigit(e.Text, e.Text.Length - 1)) e.Handled = true;
        }

        private void CloudScriptsNextPageBtn_Click(object sender, RoutedEventArgs e) {
            if (CloudScriptsPagesTxtBox.Text == "0"                     || string.IsNullOrEmpty(CloudScriptsPagesTxtBox.Text) ||
                string.IsNullOrWhiteSpace(CloudScriptsPagesTxtBox.Text) || CloudScriptsPagesTxtBox.Text == string.Empty) {
                CloudScriptsPagesTxtBox.Text = "1";

                return;
            }

            CloudScriptsPagesTxtBox.Text = (int.Parse(CloudScriptsPagesTxtBox.Text) + 1).ToString();
        }

        private void CloudScriptsPreviousPageBtn_Click(object sender, RoutedEventArgs e) {
            if (CloudScriptsPagesTxtBox.Text == "1") return;

            if (CloudScriptsPagesTxtBox.Text == "0"                     || string.IsNullOrEmpty(CloudScriptsPagesTxtBox.Text) ||
                string.IsNullOrWhiteSpace(CloudScriptsPagesTxtBox.Text) || CloudScriptsPagesTxtBox.Text == string.Empty) {
                CloudScriptsPagesTxtBox.Text = "1";

                return;
            }

            CloudScriptsPagesTxtBox.Text = (int.Parse(CloudScriptsPagesTxtBox.Text) - 1).ToString();
        }

        private void CloudScriptsSearchTxtBox_TextChanged(object sender, TextChangedEventArgs e) {
            if (string.IsNullOrEmpty(CloudScriptsSearchTxtBox.Text) || string.IsNullOrWhiteSpace(CloudScriptsSearchTxtBox.Text)) {
                CloudScriptsFeaturedLbl.Visibility        = Visibility.Visible;
                CloudScriptsFeaturedItemsPanel.Visibility = Visibility.Visible;

                FetchSearchCloudScripts();

                return;
            }

            CloudScriptsFeaturedLbl.Visibility        = Visibility.Collapsed;
            CloudScriptsFeaturedItemsPanel.Visibility = Visibility.Collapsed;

            CloudScriptsSearchTimer.Stop();
            CloudScriptsSearchTimer.Start();
        }

        private void CloudScriptsPagesTxtBox_TextChanged(object sender, TextChangedEventArgs e) {
            CloudScriptsPagesTxtBox.Text = CloudScriptsPagesTxtBox.Text.Replace(" ", string.Empty);

            if (!string.IsNullOrEmpty(CloudScriptsPagesTxtBox.Text)) {
                var filteredText = new string(CloudScriptsPagesTxtBox.Text.Where(c => char.IsDigit(c) && !char.IsWhiteSpace(c)).ToArray());

                if (filteredText != CloudScriptsPagesTxtBox.Text) {
                    CloudScriptsPagesTxtBox.Text       = filteredText;
                    CloudScriptsPagesTxtBox.CaretIndex = CloudScriptsPagesTxtBox.Text.Length;
                }
            }

            if (string.IsNullOrEmpty(CloudScriptsSearchTxtBox.Text) || string.IsNullOrWhiteSpace(CloudScriptsSearchTxtBox.Text))
                FetchSearchCloudScripts();
            else
                FetchSearchCloudScripts(true);
        }

        private void CloudScriptsModeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (string.IsNullOrEmpty(CloudScriptsSearchTxtBox.Text) || string.IsNullOrWhiteSpace(CloudScriptsSearchTxtBox.Text))
                FetchSearchCloudScripts();
            else
                FetchSearchCloudScripts(true);
        }

        private void SearchScriptsTxtBox_TextChanged(object sender, TextChangedEventArgs e) {
            var searchText = SearchScriptsTxtBox.Text.ToLower();

            if (string.IsNullOrWhiteSpace(searchText) || string.IsNullOrEmpty(searchText))
                UpdateScripts();
            else
                FilterTreeViewItems(ScriptsBox.Items, searchText);
        }

        private async void CloudScriptsInfoCloseBtn_Click(object sender, RoutedEventArgs e) {
            CloudScriptsImageInfo.Visibility = Visibility.Collapsed;

            Animations.Fade(CloudScriptsInfoBorder, CloudScriptsInfoBorder.Opacity, 0, 250);
            Animations.Fade(CloudScriptsDimBorder, CloudScriptsDimBorder.Opacity, 0, 250);

            await Task.Delay(250);
            CloudScriptsInfoBorder.Visibility = Visibility.Collapsed;
            CloudScriptsDimBorder.Visibility  = Visibility.Collapsed;
        }

        private void CloudScriptsImageInfo_CoreWebView2InitializationCompleted(object                                       sender,
                                                                               CoreWebView2InitializationCompletedEventArgs e) {
            if (e.IsSuccess) {
                CloudScriptsImageInfo.CoreWebView2.Settings.AreDefaultScriptDialogsEnabled = false;
                CloudScriptsImageInfo.CoreWebView2.Settings.AreDevToolsEnabled             = false;
                CloudScriptsImageInfo.CoreWebView2.Settings.IsGeneralAutofillEnabled       = false;
                CloudScriptsImageInfo.CoreWebView2.Settings.IsWebMessageEnabled            = false;
            }
        }

        private void CloudScriptsImageInfo_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e) {
            if (e.HttpStatusCode == 404) CloudScriptsImageInfo.ExecuteScriptAsync("document.body.innerHTML='Image does not exist.';");

            CloudScriptsImageInfo.ExecuteScriptAsync(
                "var styleElement=document.createElement('style');styleElement.innerHTML=`@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono&display=swap');*{scrollbar-width: auto;scrollbar-height: auto;scrollbar-color: #a3a3a3 #2b2b2b;}*::-webkit-scrollbar{width: 0.8vw;height: 0.8vh;}*::-webkit-scrollbar-track{background: #2b2b2b;}*::-webkit-scrollbar-thumb{background-color: #a3a3a3;border-radius: 10px;border: 0px none;}::-webkit-scrollbar-corner{background-color: #2b2b2b;}*{font-family: 'JetBrains Mono', monospace;user-select: none;}`;document.head.appendChild(styleElement);");
        }

        private void CloudScriptsInfoExecuteBtn_Click(object sender, RoutedEventArgs e) {
            DLLUtilities.Execute(currentCloudScriptSrc);
        }

        private void CloudScriptsInfoCopyBtn_Click(object sender, RoutedEventArgs e) {
            Clipboard.SetText(currentCloudScriptSrc);
        }

        private void CloudScriptsInfoOpenInNewTabBtn_Click(object sender, RoutedEventArgs e) {
            AddTab(currentCloudScriptTitle, currentCloudScriptSrc);

            ExecutionTabBtn.IsChecked = true;
        }

        private void CloudScriptsInfoOpenInScriptBloxBtn_Click(object sender, RoutedEventArgs e) {
            Process.Start($"http://scriptblox.com/script/{currentCloudScriptSlug}");
        }

        private async void ExecutionTab_KeyDown(object sender, KeyEventArgs e) {
            if ((Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)) && ExecutionTab.IsFocused && IsFocused)
                switch (e.Key) {
                    case Key.T:
                        await AddTab($"Untitled{EditorTabControl.Items.Count + 1}.lua");

                        Editor.Focus();
                        break;

                    case Key.W:
                        if (EditorTabControl.Items.Count == 1) {
                            if (MessageBox.Show(
                                    $"Are you sure you want to clear the current tab \"{(EditorTabControl.SelectedItem as TabItem).Header.ToString().Trim()}\"'s text?",
                                    "Clear Text", MessageBoxButton.YesNo) == MessageBoxResult.Yes) SetText(string.Empty, false);
                        }
                        else {
                            try {
                                if (MessageBox.Show(
                                        $"Are you sure you want to close the tab?\r\n\r\nTab Name: \"{(EditorTabControl.SelectedItem as TabItem).Header.ToString().Trim()}\"",
                                        "Close Tab", MessageBoxButton.YesNo) ==
                                    MessageBoxResult.Yes) RemoveTab(EditorTabControl.SelectedItem as TabItem);
                            }
                            catch (Exception ex) {
                                ex.ExceptionMessageBox();
                            }
                        }

                        break;
                }
        }

        private void ScriptsBoxNewFileContextMenuItem_Click(object sender, RoutedEventArgs e) {
            File.WriteAllText("./scripts/New File.lua", "");
        }

        private void ScriptsBoxNewFolderContextMenuItem_Click(object sender, RoutedEventArgs e) {
            Directory.CreateDirectory("./scripts/New Folder");
        }

        private void ScriptsBoxRefreshContextMenuItem_Click(object sender, RoutedEventArgs e) {
            SearchScriptsTxtBox.Text = string.Empty;

            UpdateScripts();
        }

        private void ScriptsBoxOpenInExplorerContextMenuItem_Click(object sender, RoutedEventArgs e) {
            Process.Start(new ProcessStartInfo {
                FileName  = "explorer.exe",
                Arguments = $"{Environment.CurrentDirectory}\\scripts"
            });
        }

        private void CloudScriptsInfoUsernameLbl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (CloudScriptsInfoUsernameLbl.Text.Contains(" ")) return;

            Process.Start($"http://scriptblox.com/u/{CloudScriptsInfoUsernameLbl.Text}");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) { }

        /*
        private void DocumentationWebView_CoreWebView2InitializationCompleted(object sender, CoreWebView2InitializationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                DocumentationWebView.CoreWebView2.Settings.AreDevToolsEnabled = false;
                DocumentationWebView.CoreWebView2.Settings.IsReputationCheckingRequired = true;
                DocumentationWebView.CoreWebView2.Settings.IsGeneralAutofillEnabled = false;
                DocumentationWebView.CoreWebView2.Settings.IsStatusBarEnabled = false;
                DocumentationWebView.CoreWebView2.Profile.PreferredColorScheme = CoreWebView2PreferredColorScheme.Dark;
                DocumentationWebView.ZoomFactor = 0.75;

                if (!AlreadySetZoomFactorChangedEvent)
                {
                    DocumentationWebView.ZoomFactorChanged += (s, e_) =>
                    {
                        DocumentationWebView.ZoomFactor = 0.75;
                    };
                }

                if (!AlreadySetDocsInitScript)
                {
                    DocumentationWebView.CoreWebView2.DOMContentLoaded += async (s, e_) =>
                    {
                        if (AlreadySetDocsInitScript)
                        {
                            DocumentationWebView.Visibility = Visibility.Collapsed;

                            await DocumentationWebView.ExecuteScriptAsync(DocsInitScript);

                            DocumentationWebView.Visibility = Visibility.Visible;

                            return;
                        }

                        using (HttpClient client = new HttpClient())
                        {
                            DocsInitScript = await client.GetStringAsync("https://github.com/VisageLabs/VisageAssets/raw/main/Docs/Init.js");
                        }

                        await DocumentationWebView.ExecuteScriptAsync(DocsInitScript);

                        DocumentationWebView.Visibility = Visibility.Visible;

                        AlreadySetDocsInitScript = true;
                    };
                }
            }
        }
        */

        private void PreventKeysTabSwitching(object sender, KeyEventArgs e) {
            switch (e.Key) {
                case Key.Home:
                    PagesTabControl.SelectedItem = ExecutionTab;
                    Editor.Focus();

                    Editor.ExecuteScriptAsync(@"
{
    let currPos = editor.getPosition();

    if (currPos)
    {
        let newPos =
        {
            lineNumber: currPos.lineNumber,
            column: 1
        };
  
        editor.setPosition(newPos);

        editor.revealPosition(newPos, monaco.editor.ScrollType.Smooth);
    }
}
                    ");

                    e.Handled = true;
                    break;

                case Key.End:
                    PagesTabControl.SelectedItem = ExecutionTab;
                    Editor.Focus();

                    Editor.ExecuteScriptAsync(@"
{
    let currPos = editor.getPosition();

    if (currPos)
    {
        let newPos =
        {
            lineNumber: currPos.lineNumber,
            column: editor.getModel().getLineContent(currPos.lineNumber).length + 1
        };

        editor.setPosition(newPos);
        editor.revealPosition(newPos, monaco.editor.ScrollType.Smooth);
    }
}
                    ");

                    e.Handled = true;
                    break;
            }
        }

        private void SettingsHideFromRecordingToggleBtn_Click(object sender, RoutedEventArgs e) {
            // WDA_EXCLUDE_FROM_CAPTURE = 0x00000011
            // WDA_MONITOR              = 0x00000000
            if (!Interop.SetWindowDisplayAffinity(Process.GetCurrentProcess().MainWindowHandle,
                                                  SettingsHideFromRecordingToggleBtn.IsEnabled ? 0x00000011 : 0x00000001)) {
                Debugger.Break();
            }
        }

        #region Variables

        // This is to tell the init class (In the classes folder) that it's initialized so I don't have to do a while loop or timer with a boolean.
        public event Action ExecutorWindowInitializedEvent;

        public static FileSystemWatcher ScriptsWatcher = new FileSystemWatcher {
            InternalBufferSize    = 16384,
            IncludeSubdirectories = true,
            Path                  = "./scripts"
        };

        public object CurrentTab { get; set; }

        public bool CanHideLoader = false;
        public bool EditorLoaded;
        public bool EditorDisposed;
        public bool EditorTabControlEventsAttached = false;

        public bool DontDoTabSwitchEvent;

        public bool ScriptsBoxCollapsed = true;
        public bool ScriptsBoxExpandingCollapsing;

        public bool DontDoPagesSwitchEvent = true;

        public string currentCloudScriptTitle;
        public string currentCloudScriptSrc;
        public string currentCloudScriptSlug;

        public bool SavedTabsLoaded;

        public MaterialIcon ResizeIcon;

        public IntPtr currentHandle = IntPtr.Zero;

        public static string DocsInitScript = string.Empty;

        private readonly DispatcherTimer UncheckPageTimer = new DispatcherTimer {
            Interval = TimeSpan.FromMilliseconds(200)
        };

        private readonly DispatcherTimer CloudScriptsSearchTimer = new DispatcherTimer {
            Interval = TimeSpan.FromMilliseconds(300)
        };

        // public static string AvalonSyntax = "";

        #endregion

        #region Methods

        public void InitSettings() {
            Height = Settings.Default.Height;
            Width  = Settings.Default.Width;

            if (Settings.Default.IsScriptsBoxCollapsed) {
                ScriptsEditorGridSplitter.Visibility = Visibility.Collapsed;

                ScriptsAndEditorColumnDefinition.MinWidth = 20;
                ScriptsAndEditorColumnDefinition.Width    = new GridLength(20);

                HideScriptsBoxBtn.IsChecked = false;

                ScriptsBoxCollapsed                    = true;
                Settings.Default.IsScriptsBoxCollapsed = true;
            }
            else {
                ScriptsAndEditorColumnDefinition.MinWidth = 130;

                ScriptsAndEditorColumnDefinition.Width = Settings.Default.ScriptsBoxWidth;
                ScriptsEditorGridSplitter.Visibility   = Visibility.Visible;

                HideScriptsBoxBtn.IsChecked = true;

                ScriptsBoxCollapsed                    = false;
                Settings.Default.IsScriptsBoxCollapsed = false;
            }
        }

        public async void Init() {
            PagesTabControl.SelectedItem = ExecutionTab;

            DontDoPagesSwitchEvent = false;

            CloudScriptsSearchTimer.Tick += CloudScriptsSearchTimerTick;

            // InitSettings();

            await Task.Delay(10);
            PagesTabControl.SelectedItem = CloudScriptsTab;

            await FetchSearchCloudScripts(false, false);
            await FetchSearchCloudScripts(false, false);

            CloudScriptsInfoScriptTxtBox.Options.AllowScrollBelowDocument    = true;
            CloudScriptsInfoScriptTxtBox.Options.HighlightCurrentLine        = true;
            CloudScriptsInfoScriptTxtBox.Options.ShowBoxForControlCharacters = true;
            CloudScriptsInfoScriptTxtBox.TextArea.TextView.ElementGenerators.Add(new AvalonLineShortener());

            using (var httpClient = new HttpClient()) {
                try {
                    using (var reader = XmlReader.Create(new StringReader(
                                                             await httpClient.GetStringAsync(
                                                                 "https://github.com/VisageLabs/VisageAssets/raw/main/Misc/AvalonSyntax.xshd")))) {
                        CloudScriptsInfoScriptTxtBox.SyntaxHighlighting = HighlightingLoader.Load(reader, HighlightingManager.Instance);
                    }
                }
                catch (Exception ex) {
                    ex.ExceptionMessageBox("Failed to add syntax highlighting to the script source box in the Cloud Scripts page.");
                }

                try {
                    var jsonContent =
                        await httpClient.GetStringAsync(
                            "https://github.com/VisageLabs/VisageAssets/raw/main/CloudScripts/FeaturedScripts.json");
                    var scripts = JArray.Parse(jsonContent);
                    foreach (var item in scripts) {
                        dynamic script = JsonConvert.DeserializeObject<object>(item.ToString());

                        var scriptItem = new CloudScriptItem(Convert.ToString(script.name), Convert.ToString(script.src),
                                                             Convert.ToString(script.game), Convert.ToString(script.views),
                                                             Convert.ToString(script.image), Convert.ToString(script.patched), "true",
                                                             Convert.ToString(script.keyLink), false);

                        scriptItem.OpenInNewTabBtn.Click += (s, e) => {
                            AddTab(Convert.ToString(script.name), Convert.ToString(script.src));

                            ExecutionTabBtn.IsChecked = true;
                        };

                        scriptItem.OpenInfoBtn.Click += async (s, e) => {
                            string title   = Convert.ToString(script.name);
                            string src     = Convert.ToString(script.src);
                            string keyLink = Convert.ToString(script.keyLink);

                            CloudScriptsInfoScriptNameLbl.Text    = title;
                            CloudScriptsInfoScriptNameLbl.ToolTip = title;
                            CloudScriptsInfoUsernameLbl.Text      = "Rune's Featured Scripts";
                            CloudScriptsInfoGameNameLbl.Text      = Convert.ToString(script.game);

                            CloudScriptsInfoFeaturesTxtBox.Text = "[RUNE]: This script is verified.\r\n\r\n";

                            CloudScriptsInfoOpenInScriptBloxBtn.Visibility = Visibility.Collapsed;

                            if (Convert.ToString(script.patched).ToLower().Contains("true"))
                                CloudScriptsInfoFeaturesTxtBox.Text += "[RUNE]: This script is patched.\r\n\r\n";

                            if (string.IsNullOrEmpty(keyLink))
                                CloudScriptsInfoFeaturesTxtBox.Text += Convert.ToString(script.description);
                            else
                                CloudScriptsInfoFeaturesTxtBox.Text +=
                                    $"[RUNE]: This script has a key system, the link to get the key is below:\r\n{keyLink}\r\n\r\n{Convert.ToString(script.description)}";

                            CloudScriptsInfoScriptTxtBox.Text = src;

                            currentCloudScriptTitle = title;
                            currentCloudScriptSrc   = src;

                            try {
                                if (!string.IsNullOrEmpty(Convert.ToString(script.image)))
                                    CloudScriptsImageInfo.Source = new Uri(Convert.ToString(script.image));
                            }
                            catch (Exception ex) {
                                ex.ExceptionMessageBox();
                            }

                            CloudScriptsInfoBorder.Visibility = Visibility.Visible;
                            CloudScriptsDimBorder.Visibility  = Visibility.Visible;

                            Animations.Fade(CloudScriptsDimBorder, CloudScriptsDimBorder.Opacity, 0.35, 250);

                            Animations.Fade(CloudScriptsInfoBorder, CloudScriptsInfoBorder.Opacity, 1, 250);

                            await Task.Delay(250);
                            CloudScriptsImageInfo.Visibility = Visibility.Visible;
                        };

                        CloudScriptsFeaturedItemsPanel.Children.Add(scriptItem);
                    }
                }
                catch (Exception ex) {
                    ex.ExceptionMessageBox("Failed to add featured scripts to the Cloud Scripts page.");
                }
            }

            await Task.Delay(10);
            PagesTabControl.SelectedItem = HomeTab;


            // call the event pointing out that it's initialized
            ExecutorWindowInitializedEvent();
        }

        public Task SaveSettings() {
            Settings.Default.Height = Height;
            Settings.Default.Width  = Width;

            Settings.Default.ScriptsBoxWidth = ScriptsAndEditorColumnDefinition.Width;

            Settings.Default.Save();

            return Task.CompletedTask;
        }

        public void ChangeMaximizeBtn(bool toMaximized = true) {
            if (toMaximized) {
                // MaximizeBtn.Content = "\xE73F";
                MaximizeBtn.Content = "\xE923";
                MaximizeBtn.ToolTip = "Restore";
            }
            else {
                MaximizeBtn.Content = "\xE71A";
                MaximizeBtn.ToolTip = "Maximize";
            }
        }

        public void MaximizeRestore() {
            switch (WindowState) {
                case WindowState.Normal:
                    WindowState = WindowState.Maximized;

                    Topmost = false;

                    ChangeMaximizeBtn();
                    break;

                case WindowState.Maximized:
                    WindowState = WindowState.Normal;

                    Topmost = Settings.Default.Topmost;

                    ChangeMaximizeBtn(false);
                    break;
            }
        }

        public async Task CloseWindow() {
            Editor.Visibility = Visibility.Collapsed;

            var currTabText = await GetText();

            EditorDisposed = true;
            Editor.Dispose();

            CloudScriptsImageInfo.Visibility = Visibility.Collapsed;
            CloudScriptsImageInfo.Dispose();

            await SaveSettings();

            Animations.Fade(MainBorderGrid, MainBorderGrid.Opacity, 0, 250);

            await Task.Delay(500);
            Hide();

            try {
                if (Directory.Exists("bin/tabs")) Directory.Delete("bin/tabs", true);

                Directory.CreateDirectory("bin/tabs");

                if (Directory.Exists("bin/tabs/selected")) Directory.Delete("bin/tabs/selected", true);

                Directory.CreateDirectory("bin/tabs/selected");

                // File.WriteAllText($"./bin/tabs/{(EditorTabControl.SelectedItem as TabItem).Header.ToString().Trim()}", currTabText);
                foreach (TabItem tab in EditorTabControl.Items) {
                    if (tab == EditorTabControl.SelectedItem) {
                        File.WriteAllText($"./bin/tabs/selected/{(EditorTabControl.SelectedItem as TabItem).Header.ToString().Trim()}",
                                          currTabText);

                        continue;
                    }

                    File.WriteAllText($"./bin/tabs/{tab.Header.ToString().Trim()}", (tab.Content as TextBox).Text);
                }
            }
            catch (Exception ex) {
                ex.ExceptionMessageBox();
            }

            Environment.Exit(0);
        }

        private SemaphoreSlim scriptsSemaphore = new SemaphoreSlim(1);

        public async Task UpdateScripts() {
            try {
                await scriptsSemaphore.WaitAsync();
                Application.Current.Dispatcher.Invoke(delegate {
                    try {
                        ScriptsBox.Items.Clear();
                        ScriptsBox.Items.Clear();
                    }
                    catch {
                        foreach (var Item in ScriptsBox.Items) ScriptsBox.Items.Remove(Item);
                    }
                });

                await PopulateScriptsBox("./scripts", ScriptsBox.Items);
            }
            finally {
                scriptsSemaphore.Release();
            }
        }

        public Task PopulateScriptsBox(string directoryPath, ItemCollection itemCollection) {
            Application.Current.Dispatcher.Invoke(async delegate {
                foreach (var dir in new DirectoryInfo(directoryPath).GetDirectories()) {
                    /*
                    ContextMenu contextMenu = new ContextMenu()
                    {
                        HasDropShadow = false,
                        Background = new SolidColorBrush(Color.FromRgb(35, 35, 35)),
                        BorderThickness = new Thickness(0)
                    };

                    foreach (MenuItem item in ScriptsBox.ContextMenu.Items)
                    {
                        contextMenu.Items.Add(item);
                    }
                    */

                    var dirItem = new TreeViewItem {
                        Header   = dir.Name,
                        ToolTip  = $"Type: Folder/Directory\r\n{dir.FullName.Replace("\\", "/")}",
                        TabIndex = 1,
                        Tag      = dir.FullName // ,
                        // ContextMenu = contextMenu
                    };

                    itemCollection.Add(dirItem);

                    /*
                    TextBox renameBox = dirItem.GetTemplateItem<TextBox>("RenameTextBox");

                    renameBox.TextChanged += (s, e) =>
                    {
                        string inputText = renameBox.Text;

                        string replacedText = Regex.Replace(inputText, "[/\\:*?\"<>|]", string.Empty);

                        if (inputText != replacedText)
                        {
                            renameBox.Text = replacedText;
                        }

                        string wordPattern = @"\b(con|prn|aux|nul|com[1-9]|lpt[1-9])\b";

                        bool contains = false;

                        if (Regex.IsMatch(inputText, wordPattern, RegexOptions.IgnoreCase) && Regex.IsMatch(inputText, $"^{wordPattern}$", RegexOptions.IgnoreCase))
                        {
                            MessageBox.Show("Matched one of the specified words!");
                        }

                        if (Regex.IsMatch(inputText, @"\.\w+$", RegexOptions.IgnoreCase))
                        {

                        }
                    };

                    renameBox.KeyDown += (s, e) =>
                    {
                        if (e.Key == Key.Enter)
                        {
                            string name = renameBox.Text.Trim();

                            if (Directory.Exists(name))
                            {
                                // MessageBox.Show("")
                            }
                            else
                            {
                                DontUpdateScripts = true;

                                Directory.Move(dir.FullName, dir.Parent.FullName + "\\" + name);

                                dirItem.Header = name;
                            }
                        }
                    };
                    */

                    await PopulateScriptsBox(dir.FullName, dirItem.Items);
                }

                foreach (var file in new DirectoryInfo(directoryPath).GetFiles()) {
                    var item = new TreeViewItem {
                        Header   = file.Name,
                        ToolTip  = $"Type: File\r\n{file.FullName.Replace("\\", "/")}\r\n\r\nDouble click to load in a new tab.",
                        TabIndex = 0,
                        Tag      = file.FullName
                    };

                    item.MouseDoubleClick += async (s, e) => { await AddTab(file.Name, File.ReadAllText(file.FullName)); };

                    itemCollection.Add(item);
                }
            });

            return Task.CompletedTask;
        }

        public bool FilterTreeViewItems(ItemCollection items, string text) {
            var showParent = false;

            foreach (TreeViewItem item in items) {
                var hasMatchingChild = FilterTreeViewItems(item.Items, text);

                if (item.Header.ToString().ToLower().Contains(text) || hasMatchingChild) {
                    item.Visibility = Visibility.Visible;
                    item.IsExpanded = true;

                    showParent = true;
                }
                else {
                    item.Visibility = Visibility.Collapsed;
                }
            }

            return showParent;
        }

        public async Task SaveAs() {
            var dialog = new SaveFileDialog {
                Title            = "Rune | Save As",
                Filter           = "Text Documents|*.txt|Lua Source Files|*.lua|Luau Source Files|*.luau|All Files & Contents|*.*",
                FilterIndex      = 3,
                RestoreDirectory = true
            };

            if (dialog.ShowDialog() == true) {
                File.WriteAllText(dialog.FileName, await GetText());

                (EditorTabControl.SelectedItem as TabItem).Tag = dialog.FileName;
            }
        }

        public async Task FetchSearchCloudScripts(bool search = false, bool animate = true) {
            try {
                CloudScriptsItemsPanel.Children.Clear();
                CloudScriptsItemsPanel.Children.Clear();

                using (var httpClient = new HttpClient()) {
                    string jsonContent;

                    // TODO: Change into new ScriptBlox API mapping.
                    // var scriptBlox = new ScriptBlox(httpClient);
                    // scriptBlox.GetQueryAsync(CloudScriptsSearchTxtBox.Text, Int32.Parse(CloudScriptsPagesTxtBox.Text), 100, true);
                    try {
                        jsonContent = await httpClient.GetStringAsync(
                            search
                                ? $"https://scriptblox.com/api/script/search?q={Uri.EscapeDataString(CloudScriptsSearchTxtBox.Text)}&page={CloudScriptsPagesTxtBox.Text}"
                                : $"https://scriptblox.com/api/script/fetch?mode={CloudScriptsModeComboBox.Text.ToLower()}&page={CloudScriptsPagesTxtBox.Text}"
                        );
                    }
                    catch (Exception) {
                        jsonContent = await httpClient.GetStringAsync(
                            search
                                ? $"https://scriptblox.com/api/script/search?q={Uri.EscapeDataString(CloudScriptsSearchTxtBox.Text)}&page={CloudScriptsPagesTxtBox.Text}"
                                : $"https://scriptblox.com/api/script/fetch?mode={CloudScriptsModeComboBox.Text.ToLower()}&page=1"
                        );
                    }

                    var scripts = (JArray)JObject.Parse(jsonContent)["result"]["scripts"];
                    foreach (var item in scripts) {
                        dynamic script = JsonConvert.DeserializeObject<object>(item.ToString());
                        dynamic scriptInfo = JsonConvert.DeserializeObject<object>(
                            await httpClient.GetStringAsync($"https://scriptblox.com/api/script/{Convert.ToString(script.slug)}"));
                        var scriptItem = new CloudScriptItem(Convert.ToString(script.title), Convert.ToString(scriptInfo.script.script),
                                                             Convert.ToString(script.game.name), Convert.ToString(script.views),
                                                             $"http://scriptblox.com{Convert.ToString(script.game.imageUrl)}",
                                                             Convert.ToString(script.isPatched), Convert.ToString(script.verified),
                                                             Convert.ToString(scriptInfo.script.keyLink), animate);

                        scriptItem.OpenInNewTabBtn.Click += (s, e) => {
                            AddTab(Convert.ToString(script.title), Convert.ToString(scriptInfo.script.script));

                            ExecutionTabBtn.IsChecked = true;
                        };

                        scriptItem.OpenInfoBtn.Click += async (s, e) => {
                            string title   = Convert.ToString(scriptInfo.script.title);
                            string src     = Convert.ToString(scriptInfo.script.script);
                            string keyLink = Convert.ToString(scriptInfo.script.keyLink);

                            CloudScriptsInfoScriptNameLbl.Text    = title;
                            CloudScriptsInfoScriptNameLbl.ToolTip = title;
                            CloudScriptsInfoUsernameLbl.Text      = Convert.ToString(scriptInfo.script.owner.username);
                            CloudScriptsInfoGameNameLbl.Text      = Convert.ToString(scriptInfo.script.game.name);

                            CloudScriptsInfoFeaturesTxtBox.Text = string.Empty;

                            CloudScriptsInfoOpenInScriptBloxBtn.Visibility = Visibility.Visible;

                            if (Convert.ToString(scriptInfo.script.verified).ToLower().Contains("true"))
                                CloudScriptsInfoFeaturesTxtBox.Text += "[RUNE]: This script is verified.\r\n\r\n";

                            if (Convert.ToString(scriptInfo.script.isPatched).ToLower().Contains("true"))
                                CloudScriptsInfoFeaturesTxtBox.Text += "[RUNE]: This script is patched.\r\n\r\n";

                            if (string.IsNullOrEmpty(keyLink))
                                CloudScriptsInfoFeaturesTxtBox.Text += Convert.ToString(scriptInfo.script.features);
                            else
                                CloudScriptsInfoFeaturesTxtBox.Text +=
                                    $"[RUNE]: This script has a key system, the link to get the key is below:\r\n{keyLink}\r\n\r\n{Convert.ToString(scriptInfo.script.features)}";

                            CloudScriptsInfoScriptTxtBox.Text = src;

                            currentCloudScriptTitle = title;
                            currentCloudScriptSrc   = src;
                            currentCloudScriptSlug  = Convert.ToString(scriptInfo.script.slug);

                            try {
                                CloudScriptsImageInfo.Source = new Uri($"http://scriptblox.com{Convert.ToString(script.game.imageUrl)}");
                            }
                            catch (Exception ex) {
                                ex.ExceptionMessageBox();
                            }

                            CloudScriptsInfoBorder.Visibility = Visibility.Visible;
                            CloudScriptsDimBorder.Visibility  = Visibility.Visible;

                            Animations.Fade(CloudScriptsDimBorder, CloudScriptsDimBorder.Opacity, 0.35, 250);

                            Animations.Fade(CloudScriptsInfoBorder, CloudScriptsInfoBorder.Opacity, 1, 250);

                            await Task.Delay(250);
                            CloudScriptsImageInfo.Visibility = Visibility.Visible;
                        };

                        CloudScriptsItemsPanel.Children.Add(scriptItem);
                    }
                }
            }
            catch (Exception) { }
        }

        /*
        public async Task SearchCloudScripts()
        {
            try
            {
                CloudScriptsItemsPanel.Children.Clear();

                using (HttpClient httpClient = new HttpClient())
                {
                    // AvalonSyntax = httpClient.GetStringAsync("https://github.com/VisageLabs/VisageAssets/raw/main/Misc/AvalonSyntax.xshd").Result;
                    string jsonContent = await httpClient.GetStringAsync($"https://scriptblox.com/api/script/search?q={Uri.EscapeDataString(CloudScriptsSearchTxtBox.Text)}&mode={CloudScriptsModeComboBox.Text.ToLower()}&page={CloudScriptsPagesTxtBox.Text}");

                    JArray scripts = (JArray)JObject.Parse(jsonContent)["result"]["scripts"];
                    foreach (JToken item in scripts)
                    {
                        dynamic script = JsonConvert.DeserializeObject<object>(item.ToString());

                        Controls.CloudScriptItem scriptItem = new Controls.CloudScriptItem(Convert.ToString(script.title), "", Convert.ToString(script.game.name), Convert.ToString(script.views), Convert.ToString(script.game.imageUrl), Convert.ToString(script.isPatched), Convert.ToString(script.verified));

                        // scriptItem.Img.Background = new ImageBrush(new BitmapImage())

                        scriptItem.OpenInNewTabBtn.Click += (s, e) =>
                        {

                        };

                        scriptItem.OpenBtn.Click += (s, e) =>
                        {

                        };

                        // MessageBox.Show($"");

                        CloudScriptsItemsPanel.Children.Add(scriptItem);

                        // await Task.Delay(250);
                    }
                }
            }
            catch
            {
            }
        }
        */

        #endregion

        #region Tab System

        public ScrollViewer TabScrollBar { get; private set; }

        // TERI: Leave this, don't touch it, the last time I messed with it the entire tab system just stopped working.
        public async Task<string> GetText(bool unescape = true) {
            var text = await Editor.ExecuteScriptAsync("editor.getValue();");

            if (text.StartsWith("\"") && text.EndsWith("\""))
                return unescape ? Regex.Unescape(text.Substring(1, text.Length - 2)) : text.Substring(1, text.Length - 2);

            return text;
        }

        public void SetText(string text, bool encode = true) {
            Editor.ExecuteScriptAsync(encode
                                          ? $"editor.setValue(\"{HttpUtility.JavaScriptStringEncode(text)}\");"
                                          : $"editor.setValue(\"{text}\");");
        }

        public async Task RemoveTab(object tab) {
            DontDoTabSwitchEvent = true;

            EditorTabControl.Items.Remove(tab);

            SetText((EditorTabControl.SelectedContent as TextBox).Text);

            CurrentTab = EditorTabControl.SelectedItem;
        }

        public async Task<dynamic[]> AddTab(string title, string text = "", bool encode = true) {
            var array = CreateTab(title, text);

            EditorTabControl.Items.Add(array[0]);
            EditorTabControl.SelectedItem = array[0];

            TabScrollBar.ScrollToRightEnd();

            SetText(text, encode);

            CurrentTab = array[0];

            return array;
        }

        public dynamic[] CreateTab(string title, string text = "") {
            var loaded = false;

            var txtBox = new TextBox {
                Focusable     = false,
                Visibility    = Visibility.Collapsed,
                IsReadOnly    = true,
                AcceptsReturn = true,
                AcceptsTab    = true
            };

            var tab = new TabItem {
                Header          = $" {title} ",
                Background      = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0)),
                Foreground      = new SolidColorBrush(Color.FromRgb(170, 170, 170)),
                BorderThickness = new Thickness(0),
                FontSize        = 13,
                Style           = TryFindResource("TabItem") as Style,
                Content         = txtBox
            };

            tab.MouseWheel += ScrollEditorTabControl;

            tab.Loaded += async delegate {
                if (!loaded) {
                    void CloseBtnClickEvent(object s_, RoutedEventArgs e_) {
                        if (EditorTabControl.Items.Count == 1) {
                            if (MessageBox.Show($"Are you sure you want to clear the tab \"{tab.Header.ToString().Trim()}\"'s text?",
                                                "Clear Text", MessageBoxButton.YesNo) == MessageBoxResult.Yes) {
                                txtBox.Text = string.Empty;

                                SetText(string.Empty, false);
                            }
                        }
                        else {
                            try {
                                if (MessageBox.Show(
                                        $"Are you sure you want to close the tab?\r\n\r\nTab Name: \"{tab.Header.ToString().Trim()}\"",
                                        "Close Tab", MessageBoxButton.YesNo) == MessageBoxResult.Yes) RemoveTab(tab);
                            }
                            catch (Exception) { }
                        }
                    }

                    try {
                        await Task.Delay(1000);
                        tab.GetTemplateItem<Button>("CloseBtn").Click += (s_, e_) => { CloseBtnClickEvent(s_, e_); };
                    }
                    catch (NullReferenceException) {
                        await Task.Delay(2000);
                        tab.GetTemplateItem<Button>("CloseBtn").Click += (s_, e_) => { CloseBtnClickEvent(s_, e_); };
                    }
                    catch (RuntimeWrappedException) {
                        await Task.Delay(2000);
                        tab.GetTemplateItem<Button>("CloseBtn").Click += (s_, e_) => { CloseBtnClickEvent(s_, e_); };
                    }
                    catch (Exception) {
                        await Task.Delay(2000);
                        tab.GetTemplateItem<Button>("CloseBtn").Click += (s_, e_) => { CloseBtnClickEvent(s_, e_); };
                    }

                    loaded = true;
                }
            };

            dynamic[] result = { tab, text };

            return result;
        }

        private void ScrollEditorTabControl(object sender, MouseWheelEventArgs e) {
            TabScrollBar.ScrollToHorizontalOffset(TabScrollBar.HorizontalOffset + e.Delta / -10);
        }

        private async void EditorTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (!DontDoTabSwitchEvent) {
                if (EditorTabControl.Items.Count > 1) { /*
                    try
                    {
                        foreach (TabItem item in EditorTabControl.Items)
                        {
                            if (item.Equals(CurrentTab))
                            {
                                (item.Content as TextBox).Text = await GetText();
                            }
                        }
                    }
                    catch
                    {
                        await Task.Delay(50);
                        foreach (TabItem item in EditorTabControl.Items)
                        {
                            if (item.Equals(CurrentTab))
                            {
                                (item.Content as TextBox).Text = await GetText();
                            }
                        }
                    }
                    */

                    // await Task.Delay(50);

                    for (var i = 0; i < EditorTabControl.Items.Count; i++)
                        if (EditorTabControl.Items[i].Equals(CurrentTab))
                            ((EditorTabControl.Items[i] as TabItem).Content as TextBox).Text = await GetText();

                    SetText((EditorTabControl.SelectedContent as TextBox).Text);
                }

                CurrentTab = EditorTabControl.SelectedItem;
            }

            DontDoTabSwitchEvent = false;
        }

        /*
        private void DragDropped(object sender, DragEventArgs e)
        {
            try
            {
                e.Effects = DragDropEffects.All;

                if (e.Data.GetData(DataFormats.FileDrop) != null)
                {
                    string[] DroppedFiles = e.Data.GetData(DataFormats.FileDrop) as string[];

                    if (DroppedFiles.Length > 0)
                    {
                        Editor().Text = File.ReadAllText(DroppedFiles[0]);
                    }
                }
                else
                {
                    if (e.Data.GetData(DataFormats.Text) != null)
                    {
                        Editor().Text = Convert.ToString(e.Data.GetData(DataFormats.Text));
                    }
                }
            }
            catch
            {
            }
        }
        */

        #endregion

        #region Settings Events

        #region Interface

        private void SettingsTopMostToggleBtn_Click(object sender, RoutedEventArgs e) {
            Topmost                  = (bool)SettingsTopMostToggleBtn.IsChecked;
            Settings.Default.Topmost = (bool)SettingsTopMostToggleBtn.IsChecked;
        }

        private void SettingsOpacityToggleBtn_Click(object sender, RoutedEventArgs e) {
            if (SettingsOpacityToggleBtn.IsChecked == true) {
                Opacity                  = 0.9;
                Settings.Default.Opacity = 0.9;
            }
            else {
                Opacity                  = 1;
                Settings.Default.Opacity = 1;
            }
        }

        #endregion

        #region DLL

        /*
        private void SettingsCustomDLLToggleBtn_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.DLL = "Custom";

            if (SettingsOxygenUDLLToggleBtn.IsLoaded)
            {
                SettingsOxygenUDLLToggleBtn.IsChecked = false;
            }
        }

        private void SettingsOxygenUDLLToggleBtn_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.DLL = "OxygenU";

            if (SettingsCustomDLLToggleBtn.IsLoaded)
            {
                SettingsCustomDLLToggleBtn.IsChecked = false;
            }
        }
        */

        #endregion

        #region Editor

        private void SettingsEditorSelectionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (EditorLoaded)
                switch (SettingsEditorSelectionComboBox.Text.ToLower()) {
                    case "monaco":
                        Settings.Default.EditorType = "Monaco";

                        Editor.ExecuteScriptAsync(
                            $"window.location.href='file:///{Directory.GetCurrentDirectory()}/bin/monaco/editor.html';");

                        // Editor.CoreWebView2.Navigate($"file:///{Directory.GetCurrentDirectory()}/bin/monaco/editor.html");
                        break;

                    case "ace":
                        Settings.Default.EditorType = "Ace";

                        Editor.ExecuteScriptAsync($"window.location.href='file:///{Directory.GetCurrentDirectory()}/bin/ace/editor.html';");

                        // Editor.CoreWebView2.Navigate($"file:///{Directory.GetCurrentDirectory()}/bin/ace/editor.html");
                        break;
                }
        }

        private void SettingsSaveTabsToggleBtn_Click(object sender, RoutedEventArgs e) {
            Settings.Default.SaveTabs = (bool)SettingsSaveTabsToggleBtn.IsChecked;
        }

        private void SettingsMonacoMinimapToggleBtn_Click(object sender, RoutedEventArgs e) {
            Settings.Default.MonacoMinimap = (bool)SettingsMonacoMinimapToggleBtn.IsChecked;

            if (Settings.Default.EditorType.ToLower() == "monaco")
                Editor.ExecuteScriptAsync("editor.updateOptions({minimap:{enabled:"                     +
                                          SettingsMonacoMinimapToggleBtn.IsChecked.ToString().ToLower() + "}});");
        }

        private void SettingsMonacoAutoIndentToggleBtn_Click(object sender, RoutedEventArgs e) {
            Settings.Default.MonacoAutoIndent = (bool)SettingsMonacoAutoIndentToggleBtn.IsChecked;

            if (Settings.Default.EditorType.ToLower() == "monaco")
                Editor.ExecuteScriptAsync("editor.updateOptions({autoIndent:"                              +
                                          SettingsMonacoAutoIndentToggleBtn.IsChecked.ToString().ToLower() + "});");
        }

        private void SettingsMonacoRenderWhitespaceToggleBtn_Click(object sender, RoutedEventArgs e) {
            Settings.Default.MonacoRenderWhitespace = (bool)SettingsMonacoRenderWhitespaceToggleBtn.IsChecked;

            if (Settings.Default.EditorType.ToLower() == "monaco")
                Editor.ExecuteScriptAsync("editor.updateOptions({renderWhitespace:"                              +
                                          SettingsMonacoRenderWhitespaceToggleBtn.IsChecked.ToString().ToLower() + "});");
        }

        private void SettingsMonacoLigaturesToggleBtn_Click(object sender, RoutedEventArgs e) {
            Settings.Default.MonacoLigatures = (bool)SettingsMonacoLigaturesToggleBtn.IsChecked;

            if (Settings.Default.EditorType.ToLower() == "monaco")
                Editor.ExecuteScriptAsync("editor.updateOptions({fontLigatures:"                          +
                                          SettingsMonacoLigaturesToggleBtn.IsChecked.ToString().ToLower() + "});");
        }

        #endregion

        #region Other

        private void SettingsUnlockFPSToggleBtn_Click(object sender, RoutedEventArgs e) {
            // Properties.Settings.Default.UnlockFPS = (bool)SettingsUnlockFPSToggleBtn.IsChecked;
        }

        private void SettingsAutoInjectToggleBtn_Click(object sender, RoutedEventArgs e) {
            // Properties.Settings.Default.AutoInject = (bool)SettingsAutoInjectToggleBtn.IsChecked;
        }

        #endregion

        #endregion

    }
}