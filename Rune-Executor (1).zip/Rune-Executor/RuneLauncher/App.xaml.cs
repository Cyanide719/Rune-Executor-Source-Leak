﻿using System.Windows;

namespace RuneLauncher {
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application { }
}