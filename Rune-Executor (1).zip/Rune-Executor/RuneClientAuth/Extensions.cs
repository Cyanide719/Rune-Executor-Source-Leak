﻿using System;
using System.Management;

namespace RuneClientAuth;

public static class utilities {
    public static string GetHardwareId() {
        var hwid = "";
        try {
            var managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystemProduct");

            foreach (var manObj in managementObjectSearcher.Get()) {
                var x = manObj["UUID"];

                if (x == null) continue;

                // UUID is there.
                hwid = x.ToString();
                break;
            }

            managementObjectSearcher.Dispose();
        }
        catch (Exception ex) {
            // If we ever need to account for certain exceptions for different messages.
            throw new Exception("Failed to get Hardware Id!");
        }

        if (hwid == "")
            throw new Exception("There was no HWID found.");

        return hwid;
    }
}