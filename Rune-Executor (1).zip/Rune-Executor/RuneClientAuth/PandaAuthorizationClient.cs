﻿using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

using Newtonsoft.Json;

namespace RuneClientAuth;

public class PandaAuthorizationClient {
    private readonly HttpClient _httpClient;

    public PandaAuthorizationClient(HttpClient httpClient) {
        _httpClient = httpClient;
    }

    public async Task<PandaJsonData?> ValidateKey(string key, string hwid, string serviceName) {
        var requestMessage =
            await _httpClient.GetAsync($"https://pandadevelopment.net/validate?service={serviceName}&hwid={hwid}&key={key}");

        return !requestMessage.IsSuccessStatusCode
            ? null
            : JsonConvert.DeserializeObject<PandaJsonData?>(await requestMessage.Content.ReadAsStringAsync());
    }

    public async Task<bool> IsKeyValid(string key, string hwid, string serviceName) {
        var keyInfo = await ValidateKey(key, hwid, serviceName);
        if (keyInfo == null) return false;

        return keyInfo.hwid == hwid && keyInfo.status == "whitelisted";
    }

    public bool TryOpenAuthPage(string hwid, string serviceName) {
        var processStartInfo = new ProcessStartInfo();
        try {
            Process.Start($"https://pandadevelopment.net/getkey?service={serviceName}&hwid={hwid}")?.Dispose();
            return true;
        }
        catch {
            return false;
        }
    }
}