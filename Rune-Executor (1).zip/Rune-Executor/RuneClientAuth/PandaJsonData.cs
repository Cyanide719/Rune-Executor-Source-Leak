﻿using System;
using System.Diagnostics;
using System.Net.Http;

using Newtonsoft.Json;

namespace RuneClientAuth;

public class PandaJsonData {
    private readonly HttpClient _httpClient;

    public string service { get; set; }
    public string hwid    { get; set; }
    public string key     { get; set; }
    public string note    { get; set; }
    public string status  { get; set; }

    public static PandaJsonData? FromJson(string json) {
        try {
            return JsonConvert.DeserializeObject<PandaJsonData>(json);
        }
        catch (Exception ex) {
#if DEBUG
            Debugger.Break(); // Break dbg
            Debug.WriteLineIf(Debugger.IsAttached, "Failed to serialise data!");
            Debug.WriteLineIf(Debugger.IsAttached, ex);
#endif
            return null;
        }
    }
}