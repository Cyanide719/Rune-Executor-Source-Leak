#include <Windows.h>
#include <iostream>
#include <string>
#include <TlHelp32.h>

#include "injection.h"

const char szDllFile[] = "dll_injection.dll";
const char szProc[] = "RobloxPlayerBeta.exe";

bool isSameString(const char* str1, const wchar_t* str2) {
    while (*str1 && *str2) {
        if (*str1 != static_cast<char>(*str2)) {
            return false;
        }
        str1++;
        str2++;
    }
    return *str1 == *str2;
}

int main() {
    PROCESSENTRY32 PE32{ 0 };
    PE32.dwSize = sizeof(PE32);

    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

    if (hSnap == INVALID_HANDLE_VALUE) {
        printf("Failed to get all proccesses! Error: %x \n", GetLastError());
        return EXIT_FAILURE;
    }

    DWORD PID = 0;
    BOOL bRet = Process32First(hSnap, &PE32);
    while (bRet) {
        if (isSameString(szProc, PE32.szExeFile)) {
            PID = PE32.th32ProcessID;
            break;
        }
        bRet = Process32Next(hSnap, &PE32);
    }

    if (PID != (DWORD)0) {
        printf("Roblox process found: %ld \n", PID);

        BOOL sidSet = setProcessSID();
        if (!sidSet) {
            printf("Failed to set process SID! \n");
            std::cout << "Press enter to exit...\n";
            std::cin.get();
            return EXIT_FAILURE;
        }

        HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, PID);
        if (!hProcess) {
            printf("Failed to open roblox process! Error: %ld \n", GetLastError());
            std::cout << "Press enter to exit...\n";
            std::cin.get();
            return EXIT_FAILURE;
        }

        ManualMapWithDelay(hProcess, szDllFile, PID, 50);

        std::cout << "Press enter to exit...\n";
        std::cin.get();
    }
    else {
        printf("Roblox is not opened! \n");
        std::cout << "Press enter to exit...\n";
        std::cin.get();
    }
 
}
