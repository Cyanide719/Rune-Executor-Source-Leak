#include "injection.h"

void __stdcall Shellcode(MANUAL_MAPPING_DATA* pData);

DWORD GetThreadIdByProcessId(DWORD processId) {
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
	if (hSnapshot == INVALID_HANDLE_VALUE) {
		return false;
	}

	THREADENTRY32 te32;
	te32.dwSize = sizeof(THREADENTRY32);

	if (Thread32First(hSnapshot, &te32)) {
		do {
			if (te32.th32OwnerProcessID == processId) {

				return te32.th32ThreadID;
				CloseHandle(hSnapshot);
				return true;
			}
		} while (Thread32Next(hSnapshot, &te32));
	}

	CloseHandle(hSnapshot);
	return 0;
}

void suspendAllThreads(DWORD processId) {
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
	if (hSnapshot == INVALID_HANDLE_VALUE) {
		printf("Failed to suspend threads! \n");
		return;
	}

	THREADENTRY32 te32;
	te32.dwSize = sizeof(THREADENTRY32);

	if (Thread32First(hSnapshot, &te32)) {
		do {
			if (te32.th32OwnerProcessID == processId) {
				HANDLE hThread = OpenThread(THREAD_ALL_ACCESS, FALSE, te32.th32ThreadID);
				SuspendThread(hThread);
				CloseHandle(hThread);
			}
		} while (Thread32Next(hSnapshot, &te32));
	}

	printf("Suspended all threads! \n");
	CloseHandle(hSnapshot);
}

void resumeAllThreads(DWORD processId) {
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
	if (hSnapshot == INVALID_HANDLE_VALUE) {
		printf("Failed to resume threads! \n");
		return;
	}

	THREADENTRY32 te32;
	te32.dwSize = sizeof(THREADENTRY32);

	if (Thread32First(hSnapshot, &te32)) {
		do {
			if (te32.th32OwnerProcessID == processId) {
				HANDLE hThread = OpenThread(THREAD_ALL_ACCESS, FALSE, te32.th32ThreadID);
				ResumeThread(hThread);
				CloseHandle(hThread);
			}
		} while (Thread32Next(hSnapshot, &te32));
	}

	printf("Resumed all threads! \n");
	CloseHandle(hSnapshot);
}

void ChangeProtectionForAllPages(HANDLE hProcess) {
	MEMORY_BASIC_INFORMATION mbi;
	LPVOID lpAddress = NULL;

	while (VirtualQueryEx(hProcess, lpAddress, &mbi, sizeof(mbi))) {
		// Check if the memory region is accessible and not in system/reserved space
		if ((mbi.State != MEM_RESERVE || mbi.Protect != PAGE_NOACCESS) &&
			(mbi.Type != MEM_IMAGE && mbi.Type != MEM_MAPPED)) {
			// Attempt to change the protection of the memory region.

			// Calculate the region size and base address.
			SIZE_T regionSize = mbi.RegionSize;
			LPVOID baseAddress = mbi.BaseAddress;

			// Use VirtualProtectEx to change the protection of the memory region.
			DWORD oldProtect;
			if (VirtualProtectEx(hProcess, baseAddress, regionSize, PAGE_READWRITE, &oldProtect)) {
				std::cout << "Successfully changed protection of " << baseAddress << " Size: " << regionSize << std::endl;
			}
			else {
				std::cerr << "Failed to change protection of memory region. Error code: " << GetLastError() << std::endl;
			}
		}
		else {
			std::cout << "Skipping inaccessible memory region." << std::endl;
		}

		// Move to the next memory region.
		lpAddress = reinterpret_cast<LPVOID>(reinterpret_cast<char*>(mbi.BaseAddress) + mbi.RegionSize);
	}
}

bool setProcessSID() {
	uint8_t security_Descriptor[SECURITY_DESCRIPTOR_MIN_LENGTH]{};

	if (!InitializeSecurityDescriptor(security_Descriptor, SECURITY_DESCRIPTOR_REVISION)) {
		printf("Failed to initialize security descriptor! Error: %x \n", GetLastError());
		return FALSE;
	}

	SID_IDENTIFIER_AUTHORITY authority = SECURITY_WORLD_SID_AUTHORITY;
	SID* everyone_sid{};

	if (!AllocateAndInitializeSid(&authority, 1, SECURITY_WORLD_RID, NULL, NULL, NULL, NULL, NULL, NULL, NULL, (PSID*)&everyone_sid)) {
		printf("Failed to allocate security descriptor! Error: %x \n", GetLastError());
		return FALSE;
	}

	DWORD dacl_size = sizeof(ACL) + sizeof(ACCESS_DENIED_ACE) - sizeof(DWORD) + GetLengthSid(everyone_sid);
	ACL* dacl = (ACL*)LocalAlloc(LPTR, dacl_size);

	if (!dacl) {
		FreeSid(everyone_sid);
		printf("Failed to allocate security descriptor in our process! Error: %x \n", GetLastError());
		return FALSE;
	}

	if (!InitializeAcl(dacl, dacl_size, ACL_REVISION)) {
		FreeSid(everyone_sid);
		LocalFree(dacl);
		printf("Failed to initialize ACL! Error: %x \n", GetLastError());
		return FALSE;
	}

	if (!AddAccessDeniedAce(dacl, ACL_REVISION, PROCESS_ALL_ACCESS, everyone_sid)) {
		FreeSid(everyone_sid);
		LocalFree(dacl);
		printf("Failed to add access denied ACE! Error: %x \n", GetLastError());
		return FALSE;
	}

	if (!SetSecurityDescriptorDacl(security_Descriptor, TRUE, dacl, FALSE)) {
		FreeSid(everyone_sid);
		LocalFree(dacl);
		printf("Failed to set security descriptor! Error: %x \n", GetLastError());
		return FALSE;
	}

	if (!SetKernelObjectSecurity(GetCurrentProcess(), DACL_SECURITY_INFORMATION, security_Descriptor)) {
		FreeSid(everyone_sid);
		LocalFree(dacl);
		printf("Failed to set kernel object security! Error: %x \n", GetLastError());
		return FALSE;
	}

	FreeSid(everyone_sid);
	LocalFree(dacl);
	printf("Sucessfully set the SID! \n");
	return TRUE;
}

bool ManualMapWithDelay(HANDLE hProc, const char* szDllFile, DWORD processId, int injectionAttempts) {


	bool injectionSuccess = false;

	for (int attempt = 1; attempt <= injectionAttempts; ++attempt) {
		std::this_thread::sleep_for(std::chrono::milliseconds(1000));

		if (ManualMap(hProc, szDllFile, processId)) {
			injectionSuccess = true;
			break;
		}
		else {
			printf("Injection attempt %d failed.\n", attempt);
		}
	}

	return injectionSuccess;
}

BOOL checkPagePermissions(HANDLE hProcess, PVOID remoteMemoryBase) {
	MEMORY_BASIC_INFORMATION mbi;
	if (!VirtualQueryEx(hProcess, remoteMemoryBase, &mbi, sizeof(mbi))) {
		printf("Failed to check new permission! Error: %ld \n", GetLastError());
		return FALSE;
	}
	printf("New page permissions: \n");
	if (mbi.Protect & PAGE_READONLY) {
		std::cout << "Read-only permission" << std::endl;
		return FALSE;
	}
	if (mbi.Protect & PAGE_READWRITE) {
		std::cout << "Read/Write permission" << std::endl;
		return FALSE;
	}
	if (mbi.Protect & PAGE_EXECUTE) {
		std::cout << "Execute permission" << std::endl;
		return FALSE;
	}
	if (mbi.Protect & PAGE_EXECUTE_READWRITE) {
		std::cout << "Execute, Read, and Write permission" << std::endl;
		return TRUE;
	}

	return FALSE;
}


bool ManualMap(HANDLE hProc, const char* szDllFile, DWORD processId) {
	BYTE* pSrcData = nullptr;
	IMAGE_NT_HEADERS* pOldNtHeader = nullptr;
	IMAGE_OPTIONAL_HEADER* pOldOptHeader = nullptr;
	IMAGE_FILE_HEADER* pOldFileHeader = nullptr;
	BYTE* pTargetBase = nullptr;

	if (!GetFileAttributesA(szDllFile)) {
		printf("Dll doesn't exist! \n");
		return FALSE;
	}

	std::ifstream File(szDllFile, std::ios::binary | std::ios::ate);

	if (File.fail()) {
		printf("Failed to open the DLL! Error %x\n", (DWORD)File.rdstate());
		return FALSE;
	}

	auto FileSize = File.tellg();
	if (FileSize < 0x1000) {
		printf("Filesize is invalid! \n");
		File.close();
		return FALSE;
	}

	pSrcData = new BYTE[static_cast<UINT_PTR>(FileSize)];
	if (!pSrcData) {
		printf("Memory allocation failed! \n");
		File.close();
		return FALSE;
	}

	File.seekg(0, std::ios::beg);
	File.read(reinterpret_cast<char*>(pSrcData), FileSize);
	File.close();

	if (reinterpret_cast<IMAGE_DOS_HEADER*>(pSrcData)->e_magic != 0x5A4D) {
		printf("Invalid file, not DLL! \n");
		delete[] pSrcData;
		return FALSE;
	}

	pOldNtHeader = reinterpret_cast<IMAGE_NT_HEADERS*>(pSrcData + reinterpret_cast<IMAGE_DOS_HEADER*>(pSrcData)->e_lfanew);
	pOldOptHeader = &pOldNtHeader->OptionalHeader;
	pOldFileHeader = &pOldNtHeader->FileHeader;

#ifdef _WIN64 
	if (pOldFileHeader->Machine != IMAGE_FILE_MACHINE_AMD64) {
		printf("Invalid 64x bit DLL! \n");
		delete[] pSrcData;
		return FALSE;
	}
#else
	if (pOldFileHeader->Machine != IMAGE_FILE_MACHINE_I386) {
		printf("Invalid 32x/x86 bit DLL! \n");
		delete[] pSrcData;
		return FALSE;
	}
#endif

	suspendAllThreads(processId);

	pTargetBase = reinterpret_cast<BYTE*>(VirtualAllocEx(hProc, reinterpret_cast<void*>(pOldOptHeader->ImageBase), pOldOptHeader->SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
	if (!pTargetBase) {
		pTargetBase = reinterpret_cast<BYTE*>(VirtualAllocEx(hProc, nullptr, pOldOptHeader->SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
		if (!pTargetBase) {
			printf("Failed to allocate memory! Error: %x \n", GetLastError());
			delete[] pSrcData;
			return FALSE;
		}
	}

	printf("Target base address 0x%x \n", pTargetBase);

	BOOL doWeHaveExecution = checkPagePermissions(hProc, pTargetBase);
	DWORD oldProtect;
	if (!doWeHaveExecution) {
		printf("We don't have execution perms, changing them now! \n");
		if (!VirtualProtectEx(hProc, pTargetBase, pOldOptHeader->SizeOfImage, PAGE_EXECUTE_READWRITE, &oldProtect)) {
			printf("Failed to get execution permissions back! Error: %x \n", GetLastError());
			return FALSE;
		}
		printf("Sucessfully changed permissions! \n");
	}

	MANUAL_MAPPING_DATA data{ 0 };
	data.pLoadLibraryA = LoadLibraryA;
	data.pGetProcAdress = reinterpret_cast<f_GetProcAdress>(GetProcAddress);

	auto* pSectionHeader = IMAGE_FIRST_SECTION(pOldNtHeader);
	for (UINT i = 0; i != pOldFileHeader->NumberOfSections; ++i, ++pSectionHeader) {
		if (pSectionHeader->SizeOfRawData) {
			if (!WriteProcessMemory(hProc, pTargetBase + pSectionHeader->VirtualAddress, pSrcData + pSectionHeader->PointerToRawData, pSectionHeader->SizeOfRawData, nullptr)) {
				printf("Can't map sections: 0x%x\n", GetLastError());
				delete[] pSrcData;
				VirtualFreeEx(hProc, pTargetBase, 0, MEM_RELEASE);
				return FALSE;
			}
		}
	}
	
	memcpy(pSrcData, &data, sizeof(data));
	WriteProcessMemory(hProc, pTargetBase, pSrcData, 0x1000, nullptr);

	delete[] pSrcData;

	void* pShellcode = VirtualAllocEx(hProc, nullptr, 0x1000, (MEM_COMMIT | MEM_RESERVE), PAGE_EXECUTE_READWRITE);
	if (!pShellcode) {
		printf("Failed to allocate memory for shellcode! Error: %x \n", GetLastError());
		VirtualFreeEx(hProc, pTargetBase, 0, MEM_RELEASE);
		return FALSE;
	}

	printf("Shell address 0x%x \n", pShellcode);

	WriteProcessMemory(hProc, pShellcode, Shellcode, 0x1000, nullptr);

	HANDLE hThread = CreateRemoteThread(hProc, nullptr, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(pShellcode), pTargetBase, 0, nullptr);
	if (!hThread) {
		printf("Failed to create remote thread! Error: %x \n", GetLastError());
		VirtualFreeEx(hProc, pTargetBase, 0, MEM_RELEASE);
		VirtualFreeEx(hProc, pShellcode, 0, MEM_RELEASE);
		return FALSE;
	}

	resumeAllThreads(processId);

	auto start = std::chrono::high_resolution_clock::now();
	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> elapsed = end - start;

	const double timeout = 1;

	HINSTANCE hCheck = NULL;
	while (!hCheck && elapsed.count() < timeout)
	{
		MANUAL_MAPPING_DATA data_checked{ 0 };
		ReadProcessMemory(hProc, pTargetBase, &data_checked, sizeof(data_checked), nullptr);
		hCheck = data_checked.hMod;

		end = std::chrono::high_resolution_clock::now();
		elapsed = end - start;

		Sleep(10);
	}

	if (elapsed.count() >= timeout)
	{
		printf("Timed out! \n");
		VirtualFreeEx(hProc, pShellcode, 0, MEM_RELEASE);
		VirtualFreeEx(hProc, pTargetBase, 0, MEM_RELEASE);
		return FALSE;
	}

	DWORD oldProtectOld;
	BOOL changed = VirtualProtect(pShellcode, pOldOptHeader->SizeOfImage, PAGE_EXECUTE, &oldProtectOld);

	if (changed) {
		printf("Changed perms to execute! \n");
	}
	else {
		printf("Could not change perms! \n");
	}

	printf("Sucessfully done! \n");

	return TRUE;
}

#define RELOC_FLAG32(RelInfo) ((RelInfo >> 0x0C) == IMAGE_REL_BASED_HIGHLOW)
#define RELOC_FLAG64(RelInfo) ((RelInfo >> 0x0C) == IMAGE_REL_BASED_DIR64)

#ifdef _WIN64
#define RELOC_FLAG RELOC_FLAG64
#else
#define RELOC_FLAG RELOC_FLAG32
#endif

void __stdcall Shellcode(MANUAL_MAPPING_DATA* pData)
{
	if (!pData)
		return;

	BYTE* pBase = reinterpret_cast<BYTE*>(pData);
	auto* pOpt = &reinterpret_cast<IMAGE_NT_HEADERS*>(pBase + reinterpret_cast<IMAGE_DOS_HEADER*>(pData)->e_lfanew)->OptionalHeader;

	pData->hMod = reinterpret_cast<HINSTANCE>(pBase);

	auto _LoadLibraryA = pData->pLoadLibraryA;
	auto _GetProcAdress = pData->pGetProcAdress;
	auto _DllMain = reinterpret_cast<f_DLL_ENTRY_POINT>(pBase + pOpt->AddressOfEntryPoint);

	BYTE* locationDelta = pBase - pOpt->ImageBase;

	if (locationDelta) {
		if (!pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size)
			return;

		auto* pRelocData = reinterpret_cast<IMAGE_BASE_RELOCATION*>(pBase + pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress);

		while (pRelocData->VirtualAddress)
		{
			UINT AmountOfEntries = (pRelocData->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
			WORD* pRelativeInfo = reinterpret_cast<WORD*>(pRelocData + 1);

			for (UINT i = 0; i != AmountOfEntries; ++i, ++pRelativeInfo) {
				if (RELOC_FLAG(*pRelativeInfo)) {
					UINT_PTR* pPatch = reinterpret_cast<UINT_PTR*>(pBase + pRelocData->VirtualAddress + ((*pRelativeInfo) & 0xFFF));
					*pPatch += reinterpret_cast<UINT_PTR>(locationDelta);
				}
			}

			pRelocData = reinterpret_cast<IMAGE_BASE_RELOCATION*>(reinterpret_cast<BYTE*>(pRelocData) + pRelocData->SizeOfBlock);
		}
	}

	if (pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size) {
		auto* pImportDescr = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(pBase + pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);

		while (pImportDescr->Name)
		{
			char* szMod = reinterpret_cast<char*>(pBase + pImportDescr->Name);
			HINSTANCE hDll = _LoadLibraryA(szMod);
			ULONG_PTR* pThunkRef = reinterpret_cast<ULONG_PTR*>(pBase + pImportDescr->OriginalFirstThunk);
			ULONG_PTR* pFuncRef = reinterpret_cast<ULONG_PTR*>(pBase + pImportDescr->FirstThunk);

			if (!pThunkRef) {
				pThunkRef = pFuncRef;
			}

			for (; *pThunkRef; ++pThunkRef, ++pFuncRef) {
				if (IMAGE_SNAP_BY_ORDINAL(*pThunkRef)) {
					*pFuncRef = _GetProcAdress(hDll, reinterpret_cast<char*>(*pThunkRef & 0xFFFF));
				}
				else {
					auto* pImport = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(pBase + (*pThunkRef));
					*pFuncRef = _GetProcAdress(hDll, pImport->Name);
				}
			}

			++pImportDescr;
		}
	}

	if (pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size) {
		auto* pTLS = reinterpret_cast<IMAGE_TLS_DIRECTORY*>(pBase + pOpt->DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress);
		auto* pCallback = reinterpret_cast<PIMAGE_TLS_CALLBACK*>(pTLS->AddressOfCallBacks);

		for (; pCallback && *pCallback; ++pCallback)
			(*pCallback) (pBase, DLL_PROCESS_ATTACH, nullptr);
	}

	_DllMain(pBase, DLL_PROCESS_ATTACH, nullptr);
}
